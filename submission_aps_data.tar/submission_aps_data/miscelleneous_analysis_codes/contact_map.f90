program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,k_temp
integer,parameter::npart=460
character(len=30) :: charac_a
character(len=2)::charac_b
real*8::tempx,tempy,tempz
real*8,parameter::contact_dist_thresh=2.0d0
real*8::pos(3*npart)
real*8::dx,dy,dz,dd
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer:: visited(npart)
real*8:: no_part_in_cluster(npart)
real*8::contact_prob(460),k_count_seg(460)!!!!!!!!!!!!! Change this for diff loop sizes!!!!!!!!!!!!!!
real*8::av_contact_prob(460,460),count_contact(460,460)!!!!!!!!!!!!!!!!!!!!!!!!!
!allocate(visited(npart),no_part_in_cluster(npart))

bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

av_contact_prob=0.0d0
av_k_count_seg=0.0d0


!pos=0.0d0
k3=0
do i=10000,1000000,10000

pos=0.0d0
bond_index=0.0d0
neigh_list=0.0d0
no_neighbors=0.0d0



!do i=500000,500000
charac_a ='store_'

       call addnumtostring(charac_a,i)
!write(*,*)charac_a
k3=0
!av_contact_prob=0.0d0
!av_k_count_seg=0.0d0
       open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)tempx,tempy,tempz
if(charac_b.eq.'O')then
k3=k3+1
pos(3*k3-2)=tempx
pos(3*k3-1)=tempy
pos(3*k3)=tempz

!write(*,*)k3,pos(3*k3)
!write(*,*)k3,j
endif
enddo

!!!!!!!!!!!! Contact Probability !!!!!!!!!!!!!!!!!!!!

contact_prob=0.0d0
k_count_seg=0.0d0
do k1=1,460 !!!!!!!Loop segment !!!!!!!!!!!!!!!!
do k2=1,460

if(k1.ne.k2)then

count_contact(k1,k2)=count_contact(k1,k2) +1.0d0
!count_contact(k2,k1)=count_contact(k2,k1) +1.0d0

dx=pos(3*k2-2) -pos(3*k1-2)
dy=pos(3*k2-1) -pos(3*k1-1)
dz=pos(3*k2) -pos(3*k1)

dd=dx**2.0d0 + dy**2.0d0 + dz**2.0d0


if(dd.lt.contact_dist_thresh)then

!count_contact(k1,k2)=count_contact(k1,k2) +1.0d0
av_contact_prob(k1,k2)=av_contact_prob(k1,k2) + 1.0d0
!av_contact_prob(k2,k1)=av_contact_prob(k2,k1) + 1.0d0

endif

endif


enddo
enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
close(083)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
enddo


do k1=1,460 !!!!!!!Loop segment !!!!!!!!!!!!!!!!
do k2=1,460

if(k1.ne.k2)then

write(33,*)k1,k2,av_contact_prob(k1,k2)/count_contact(k1,k2)

endif


enddo
enddo








contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
