program dist_nus

implicit none

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,ii,iw
integer,parameter::npart=7
integer,parameter::frames=(7160000-500000)/100000
!integer:: frame_count
character(len=30) :: charac_a
character(len=2)  :: charac_b
character(len=3)  :: charac_d

real*8::tempx,tempy,tempz
real*8,parameter::cluster_dist_thresh=3.0d0
real*8::pos(3*npart),dx,dy,dz,dd
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart),num(frames),mon_index(frames,7)

integer:: visited(npart),i9
real*8:: no_part_in_cluster(npart)

! ========= NEW for storing configurations =========
integer :: max_configs, config_n, frame_count,frame_count_global
character(len=30), allocatable :: config_list(:)
integer, allocatable :: config_count(:)
! ==================================================

real*8::contact_prob(250),k_count_seg(250)
real*8::av_contact_prob(250),av_k_count_seg(250)

! ===================================================================
! INITIALIZATION
! ===================================================================

bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0
av_contact_prob=0.0d0
av_k_count_seg=0.0d0

! configuration storage
max_configs = 120
allocate(config_list(max_configs))
allocate(config_count(max_configs))
config_list = ''
config_count = 0
config_n = 0
frame_count = 0
frame_count_global=0
! ===================================================================
! MAIN LOOP
! ===================================================================

do i9=1,10

charac_a='store_'
bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

charac_d='r'
call addnumtostring(charac_d,i9)

k3=0
frame_count=0

do i=500000,7160000,100000
frame_count=frame_count+1
frame_count_global=frame_count_global +1

    pos=0.0d0
    bond_index=0.0d0
    neigh_list=0.0d0
    no_neighbors=0.0d0

    charac_a =trim(charac_d)//'/store_'
    call addnumtostring(charac_a,i)
    write(*,*) charac_a

    k3=0
    open(83,file=charac_a,status='unknown',form='formatted')

    do j=1,1867
        read(83,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
        if(charac_b.eq.'H')then
            k3=k3+1
            pos(3*k3-2)=tempx
            pos(3*k3-1)=tempy
            pos(3*k3)=tempz

!write(*,*)k3,pos(3*k3)
    endif
    enddo
!write(*,*)'hi'
    ! ------------------------------------------------------------------
    ! BUILD mon_index FOR THIS FRAME
    ! ------------------------------------------------------------------
  mon_index=0.0d0
    k1=0
    do ii=1,npart-1
        do j=ii+1,npart
            k1=k1+1
 !     write(*,*)pos(3*ii),pos(3*j)
            dx=pos(3*ii-2)-pos(3*j-2)
            dy=pos(3*ii-1)-pos(3*j-1)
            dz=pos(3*ii)-pos(3*j)
            dd=dsqrt(dx*dx + dy*dy + dz*dz)

   !         write(*,*)ii,j
            if(dd.lt.1.50d0)then
!write(*,*)i,ii,j
                    mon_index(frame_count,ii)=1.0d0
                mon_index(frame_count,j)=1.0d0
            endif

        enddo
    enddo

    close(83)
write(*,*)'hi',i
    ! =============================================================
    ! ==========  NEW: EXTRACT CLUSTER CONFIGURATIONS  =============
    ! =============================================================
!    frame_count = frame_count + 1

    visited = 0

    do ii=1,npart

        if(visited(ii) == 1) cycle

        cluster_index = 0
        charac_a = '('

        do j=1,npart
            if(mon_index(frame_count,j) == 1.0d0) then
                visited(j) = 1
                cluster_index = cluster_index + 1
                write(charac_b,'(I2)') j
                charac_a = trim(charac_a)//trim(adjustl(charac_b))//','
            end if
        end do

        if(cluster_index > 0) then
            ! Replace last comma with ')'
            charac_a(len_trim(charac_a):len_trim(charac_a)) = ')'

            added = 0
            do j=1,config_n
                if(trim(config_list(j)) == trim(charac_a)) then
                    config_count(j) = config_count(j) + 1
                    added = 1
                    exit
                endif
            enddo

            if(added == 0) then
                config_n = config_n + 1
                config_list(config_n) = charac_a
                config_count(config_n) = 1
            endif

        endif

    enddo
    ! =============================================================

enddo
enddo

! ===================================================================
! FINAL OUTPUT
! ===================================================================

open(99,file='cluster_probabilities.txt',status='unknown')

do iw=1,config_n
    write(99,'(A,3X,F12.8)') trim(config_list(iw)), &
        real(config_count(iw))/real(frame_count_global)
end do

close(99)

contains

! =============================================================
! STRING CONCAT HELPERS
! =============================================================
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

snum=number
do i=len(string),1,-1
    if (string(i:i) .ne. ' ') goto 10
enddo
10 strlen=i

nodig=int(log10(1.0*snum+0.1))+1
do i=nodig,1,-1
    num=snum/10**(i-1)
    string(strlen+1:strlen+1)=char(48+num)
    strlen=strlen+1
    snum=snum-num*10**(i-1)
enddo

return
end subroutine addnumtostring

end program dist_nus

