program sort_cluster_probabilities

    implicit none
    integer, parameter :: max_configs = 2000
    character(len=20) :: config(max_configs)   ! store loop configurations like (1,2,3)
    real*8 :: prob(max_configs)
    integer :: n, i, j
    character(len=20) :: tmp_config
    real*8 :: tmp_prob
    character(len=50) :: line
    integer :: ios

    n = 0
    open(10, file="cluster_probabilities.txt", status="old", action="read")

    do
        read(10,'(A)', iostat=ios) line
        if (ios /= 0) exit
        n = n + 1
        read(line, '(A,F12.8)') config(n), prob(n)
    end do

    close(10)

    ! --------------------------------------------------------
    ! Sort in descending order of probability (simple bubble sort)
    ! --------------------------------------------------------
    do i = 1, n-1
        do j = i+1, n
            if (prob(j) > prob(i)) then
                tmp_prob = prob(i)
                prob(i) = prob(j)
                prob(j) = tmp_prob

                tmp_config = config(i)
                config(i) = config(j)
                config(j) = tmp_config
            end if
        end do
    end do

    ! --------------------------------------------------------
    ! Write sorted output
    ! --------------------------------------------------------
    open(20, file="cluster_probabilities_sorted.txt", status="unknown")
    do i = 1, n
        write(20,'(A,2X,F12.8)') trim(config(i)), prob(i)
    end do
    close(20)

end program sort_cluster_probabilities

