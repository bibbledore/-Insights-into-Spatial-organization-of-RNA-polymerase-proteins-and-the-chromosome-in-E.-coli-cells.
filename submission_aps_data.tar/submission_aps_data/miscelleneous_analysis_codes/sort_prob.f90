program sort_cluster_probabilities

    implicit none
    integer, parameter :: max_configs = 2000
    integer :: id(max_configs)
    real*8 :: prob(max_configs)
    integer :: n, i, j
    integer :: tmp_id
    real*8 :: tmp_prob

    ! Read the input file
    n = 0
    open(10, file="cluster_probabilities.txt", status="old", action="read")

    do
        n = n + 1
        read(10, *, end=100) id(n), prob(n)
    end do

100 continue
    n = n - 1
    close(10)

    ! --------------------------------------------------------
    ! Sort in descending order of probability (bubble sort)
    ! --------------------------------------------------------
    do i = 1, n-1
        do j = i+1, n
            if (prob(j) > prob(i)) then
                tmp_prob = prob(i)
                prob(i) = prob(j)
                prob(j) = tmp_prob

                tmp_id = id(i)
                id(i) = id(j)
                id(j) = tmp_id
            end if
        end do
    end do

    ! --------------------------------------------------------
    ! Write sorted output
    ! --------------------------------------------------------
    open(20, file="cluster_probabilities_sorted.txt", status="unknown")

    do i = 1, n
        write(20,'(I6,2X,F12.8)') id(i), prob(i)
    end do

    close(20)

end program sort_cluster_probabilities

