program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,ii
integer,parameter::npart=7
character(len=30) :: charac_a
character(len=2)::charac_b
real*8::tempx,tempy,tempz
real*8,parameter::cluster_dist_thresh=3.0d0
real*8::pos(3*npart),dx,dy,dz,dd
!real*8::dx,dy,dz,dd
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer:: visited(npart),time_k
real*8:: no_part_in_cluster(npart)
real*8::contact_prob(250),k_count_seg(250)!!!!!!!!!!!!! Change this for diff loop sizes!!!!!!!!!!!!!!
real*8::av_contact_prob(250),av_k_count_seg(250)!!!!!!!!!!!!!!!!!!!!!!!!!
!allocate(visited(npart),no_part_in_cluster(npart))

bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

av_contact_prob=0.0d0
av_k_count_seg=0.0d0

time_k=0
!pos=0.0d0
k3=0
do i=10000,8160000,10000

time_k=time_k +1


pos=0.0d0
bond_index=0.0d0
neigh_list=0.0d0
no_neighbors=0.0d0



!do i=500000,500000
charac_a ='store_'

       call addnumtostring(charac_a,i)
!write(*,*)charac_a
k3=0
!av_contact_prob=0.0d0
!av_k_count_seg=0.0d0
       open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)tempx,tempy,tempz
if(charac_b.eq.'H')then
k3=k3+1
pos(3*k3-2)=tempx
pos(3*k3-1)=tempy
pos(3*k3)=tempz
!write(*,*)k3
endif
enddo

!!!!!!!!!!!! Distribution of operon distances !!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
dx=pos(3*3-2)-pos(3*1-2)
dy=pos(3*3-1)-pos(3*1-1)
dz=pos(3*3)-pos(3*1)

dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)


write(21,*)dd,dd

close(083)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
enddo









contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
