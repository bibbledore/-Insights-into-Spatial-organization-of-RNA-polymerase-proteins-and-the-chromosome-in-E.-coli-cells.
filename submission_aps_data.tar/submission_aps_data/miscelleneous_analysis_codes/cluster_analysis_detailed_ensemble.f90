program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer,parameter::npart=1867
character(len=30) :: charac_a
character(len=2)::charac_b
character(len=3)::charac_d
integer::cluster_id(npart),i9
real*8::tempx,tempy,tempz
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart)
real*8::dx,dy,dz,dd
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)
integer,parameter :: nbins = 10
real*8,parameter :: rmax = 1.0d0
real*8 :: dr, r, shell_vol
real*8 :: hist_C(nbins), hist_Na(nbins)
integer :: bin




!allocate(visited(npart),no_part_in_cluster(npart))

do i9=1,1

charac_d='r'
call addnumtostring(charac_d,i9)






bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

!pos=0.0d0
k3=0
do i=1000000,7570000,100000

pos=0.0d0
bond_index=0.0d0
neigh_list=0.0d0
no_neighbors=0.0d0





charac_a =trim(charac_d)//'/store_'

write(*,*)charac_a


!do i=500000,500000
!charac_a ='store_'

       call addnumtostring(charac_a,i)
!write(*,*)charac_a
k3=0

       open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)tempx,tempy,tempz
!if(charac_b.eq.'N'.or.charac_b.eq.'Na')then
!if(charac_b.eq.'N'.or.charac_b.eq.'Na')then
k3=k3+1
pos(3*k3-2)=tempx
pos(3*k3-1)=tempy
pos(3*k3)=tempz
!write(*,*)k3,j

if(charac_b.eq.'N')then
bond_index(k3)=1.0d0
!write(*,*)i,j,k3,bond_index(k3),charac_b
elseif(charac_b.eq.'Na')then
bond_index(k3)=2.0d0
endif


!endif


enddo
close(083)
!! Basically a neighbor list
do k1=1,npart-1
do k2=k1+1,npart
dx=pos(3*k1-2)-pos(3*k2-2)
dy=pos(3*k1-1)-pos(3*k2-1)
dz=pos(3*k1)-pos(3*k2)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.cluster_dist_thresh)then
!write(*,*)'hi'
neigh_list(k1,k2)=1.0d0
neigh_list(k2,k1)=1.0d0
no_neighbors(k1)=no_neighbors(k1) +1.0d0
no_neighbors(k2)=no_neighbors(k2) +1.0d0
endif
enddo
enddo
!write(*,*)'hi'
!!!Now count number of clusters!!!!!!!



!!! Now count number of clusters
cluster_index = 0
cluster_index_actual=0
visited = 0
visited_actual=0
no_part_in_cluster = 0
no_part_in_cluster_actual = 0
cluster_id=0



do k1 = 1, npart
   if (visited(k1) == 0) then
      cluster_index = cluster_index + 1
      no_part_in_cluster(cluster_index) = 0.0d0

      ! Start cluster
      visited(k1) = 1
      no_part_in_cluster(cluster_index) = no_part_in_cluster(cluster_index) +1.0d0
cluster_id(k1) = cluster_index
      ! Expand cluster
      added = 1
      do while (added == 1)
         added = 0
         do k2 = 1, npart
            if (visited(k2) == 0) then
               do j = 1, npart
                  if (visited(j) == 1 .and. neigh_list(k2,j) == 1.0d0) then
                     visited(k2) = 1
                     no_part_in_cluster(cluster_index)=no_part_in_cluster(cluster_index) + 1.0d0
                  cluster_id(k2) = cluster_index
                     added = 1
                     exit
                  endif
               end do
            endif
         end do
      end do

      ! Now cluster is complete
         if (no_part_in_cluster(cluster_index) > 5.0d0) then
         cluster_index_actual = cluster_index_actual + 1
         no_part_in_cluster_actual(cluster_index_actual) = no_part_in_cluster(cluster_index)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!        
 ! Mark all particles in this cluster as actual
         do p = 1, npart
            if (visited(p) == 1) visited_actual(p) = 1
            !write(*,*)p
         end do
    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
       end if
   end if
end do

visited_actual_max=0.0d0
imax = 1
do ii = 2, cluster_index
   if (no_part_in_cluster(ii) > no_part_in_cluster(imax)) then
      imax = ii
   end if
end do

!print *, "Largest cluster is ", imax, " with ", no_part_in_cluster(imax), "
!particles."

!----------------------------
! Mark all members of largest cluster
!----------------------------
do k = 1, npart
   if (cluster_id(k) == imax) then
      visited_actual_max(k) = 1   ! or any marker you want
   else
      visited_actual_max(k) = 0
   end if
end do

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!write(12,*)i, cluster_index_actual
!write(13,*)i,sum(no_part_in_cluster_actual)/cluster_index_actual
!!!! fraction of bonded particles in cluster!!!!!!!

k_count=0

do i1=1,npart
!write(*,*)i1,bond_index(i1),visited(i1)

if(bond_index(i1).eq.2.0d0)then
if(visited_actual_max(i1).eq.1)then
k_count=k_count+1
!write(*,*)k_count/700.0d0
endif
endif

enddo

!if(sum(no_part_in_cluster_actual).ne.0.0d0)then 
!write(14,*)i,k_count/sum(no_part_in_cluster_actual)
write(14,*)k_count,k_count
!endif
!!!!!!!!!!!!!!!!!!!!!!!



pos_x_com=0.0d0
pos_y_com=0.0d0
pos_z_com=0.0d0
k_count2=0.0d0
do i1=1,npart
if(visited_actual_max(i1).eq.1)then
pos_x_com=pos_x_com + pos(3*i1-2)
pos_y_com=pos_y_com + pos(3*i1-1)
pos_z_com=pos_z_com + pos(3*i1)
k_count2=k_count2+1.0d0
endif
enddo
pos_x_com=pos_x_com/k_count2;pos_y_com=pos_y_com/k_count2
pos_z_com=pos_z_com/k_count2
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



!!!!!!!! Radius of gyration !!!!!!!!!!!!!!!!!!!!!!!!!

av_dd_temp=0.0d0
do i1=1,npart

if(visited_actual_max(i1).eq.1)then

dx_temp=pos(3*i1-2)-pos_x_com
dy_temp=pos(3*i1-1)-pos_y_com
dz_temp=pos(3*i1)-pos_z_com

dd_temp=dx_temp**2.0d0 + dy_temp**2.0d0 + dz_temp**2.0d0

av_dd_temp=av_dd_temp + dd_temp
endif


enddo

av_dd_temp=av_dd_temp/k_count2


write(63,*)i,sqrt(av_dd_temp)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

dr = rmax/nbins
hist_C = 0.0d0
hist_Na = 0.0d0


do i1=1,npart
if(visited_actual_max(i1).eq.1)then
if(bond_index(i1).eq.1.0d0)then
ddx=pos(3*i1-2)-pos_x_com
ddy=pos(3*i1-1)-pos_y_com
ddz=pos(3*i1)-pos_z_com
dd=dsqrt(ddx**2.0d0 + ddy**2.0d0 + ddz**2.0d0)


!write(82,*)dd,dd

if(dd.lt.rmax)then
bin = int(dd/dr) + 1
!endif

hist_C(bin) = hist_C(bin) + 1.0d0
endif

endif
endif
enddo


bin=0.0d0


k3=0
do i1=1,npart
if(visited_actual_max(i1).eq.1)then
if(bond_index(i1).eq.2.0d0)then
!if(bond_index(i1).lt.2.0d0)then
ddx=pos(3*i1-2)-pos_x_com
ddy=pos(3*i1-1)-pos_y_com
ddz=pos(3*i1)-pos_z_com
dd=dsqrt(ddx**2.0d0 + ddy**2.0d0 + ddz**2.0d0)
k3=k3+1
!write(*,*)k3
!write(73,*)dd,dd
!endif


if(dd.lt.rmax)then
bin = int(dd/dr) + 1
!endif

hist_Na(bin) = hist_Na(bin) + 1.0d0

endif



endif
endif
enddo









enddo

enddo





do k1=1,nbins

r = (k1-0.5d0)*dr
shell_vol = 4.0d0*3.14159265358979d0*r*r*dr

if(shell_vol.gt.0.0d0)then

write(82,*) r, hist_C(k1)/(shell_vol*sum(hist_C))*(1.33*3.1415926d0*r*r*r)
write(73,*) r, hist_Na(k1)/(shell_vol*sum(hist_Na))*(1.33*3.1415926d0*r*r*r)

!write(*,*)(hist_Na(k1)/(shell_vol*sum(hist_Na))*shell_vol)


endif

enddo










contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
