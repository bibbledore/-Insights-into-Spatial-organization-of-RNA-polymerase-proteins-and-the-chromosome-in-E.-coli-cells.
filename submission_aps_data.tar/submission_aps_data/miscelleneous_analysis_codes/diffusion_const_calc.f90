program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer,parameter::npart=400
integer,parameter::max_no_frames=(7500000-5500000)/10000
character(len=30) :: charac_a,charac_z
character(len=2)::charac_b
integer::cluster_id(npart)
real*8::tempx,tempy,tempz,temp
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart),k_c
real*8::dx,dy,dz,dd,x_com,y_com,z_com,rad_g,dd2
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
integer::frame_count,residence_time
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)
real*8:: entry_time(npart,max_no_frames),exit_time(npart,max_no_frames)
real*8:: cluster_index_frame(npart,max_no_frames)
real*8::first_entry_time(npart),first_exit_time(npart)
real*8:: entry_recorded(npart),instances_of_clustering(npart),frame_where_in_cluster(npart,max_no_frames)
real*8:: cluster_label(npart),no_of_clusters
real*8:: pos_store_frames_x(max_no_frames),pos_store_frames_y(max_no_frames),pos_store_frames_z(max_no_frames)
integer::this_frame,prev_frame
real*8::dist_frame(max_no_frames),count_frames(max_no_frames)


do k9=1,npart

charac_z='D'
call addnumtostring(charac_z,k9)

open(084,file='diff_files/'//trim(charac_z),status='unknown',form='formatted')


count_frames=0.0d0
dist_frame=0.0d0

cluster_index_frame=0.0d0
!allocate(visited(npart),no_part_in_cluster(npart))
instances_of_clustering=0.0d0
frame_where_in_cluster=0.0d0
bond_index=0.0d0
charac_a ='store_'

!pos=0.0d0
k3=0
frame_count=0
do i=5500000,7500000,10000
frame_count=frame_count+1
pos=0.0d0
bond_index=0.0d0
charac_a ='store_'
       call addnumtostring(charac_a,i)
k3=0
open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)j,charac_b,tempx,tempy,tempz
if(charac_b.eq.'Na')then
!if(charac_b.eq.'Na')then
k3=k3+1
pos(3*k3-2)=tempx
pos(3*k3-1)=tempy
pos(3*k3)=tempz

if(k3.eq.k9)then
pos_store_frames_x(frame_count)=pos(3*k3-2)
pos_store_frames_y(frame_count)=pos(3*k3-1)
pos_store_frames_z(frame_count)=pos(3*k3)
endif

endif


enddo
close(083)


do i=1,max_no_frames-1
do j=i+1.max_no_frames

k4=j-i
dx=pos_store_frames_x(j)-pos_store_frames_x(i)
dy=pos_store_frames_y(j)-pos_store_frames_y(i)
dz=pos_store_frames_z(j)-pos_store_frames_z(i)

dist_frames(k4)=sqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
count_frames(k4)=count_frames(k4)+1.0d0

enddo
enddo

dist_frames=dist_frames/count_frames

do i=1,max_no_frames
write(84,*)i,dist_frames(i)
enddo

close(84)

enddo

contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
