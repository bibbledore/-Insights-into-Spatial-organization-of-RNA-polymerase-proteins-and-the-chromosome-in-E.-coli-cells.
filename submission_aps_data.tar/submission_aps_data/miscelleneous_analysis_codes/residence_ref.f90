program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer,parameter::npart=400
integer,parameter::max_no_frames=(7500000-5500000)/10000
character(len=30) :: charac_a
character(len=3)::charac_d
character(len=2)::charac_b
integer::cluster_id(npart)
real*8::tempx,tempy,tempz,temp
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart),k_c
real*8::dx,dy,dz,dd,x_com,y_com,z_com,rad_g,dd2
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart),delta_x,delta_z
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
integer::frame_count,residence_time
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)
real*8:: entry_time(npart,max_no_frames),exit_time(npart,max_no_frames)
real*8:: cluster_index_frame(npart,max_no_frames)
real*8::first_entry_time(npart),first_exit_time(npart)
real*8:: entry_recorded(npart),instances_of_clustering(npart),frame_where_in_cluster(npart,max_no_frames)
real*8::z_out_cluster,x_out_cluster,y_out_cluster
integer::this_frame,prev_frame,i7,i8
integer,parameter::seed=326530

open(72,file='t.dat',status='unknown',form='formatted')


do i8=1,1

write(*,*)i8

charac_d='r'
call addnumtostring(charac_d,i8)


delta_z=0.0d0
delta_x=0.0d0

do i7=1,140


cluster_index_frame=0.0d0
!allocate(visited(npart),no_part_in_cluster(npart))
instances_of_clustering=0.0d0
frame_where_in_cluster=0.0d0



bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

!pos=0.0d0
k3=0
frame_count=0



!!!!!!!!!!!!!Define a region outside the cluster!!!!!!!!!!!!!!!!!!
!do i7=1,70

delta_z=delta_z+ 0.10d0*i7*(rand())
delta_x=delta_x+ 0.10d0*i7*(rand())

z_out_cluster=500.0d0-8.750d0 +delta_z   
y_out_cluster=500.0d0 - 3.50d0*delta_x
x_out_cluster=500.0d0-3.50d0 + delta_x


!write(*,*)delta_z,delta_x



!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!






do i=5500000,7500000,10000

visited_actual_max=0



charac_a =trim(charac_d)//'/store_'

!write(*,*)charac_a


frame_count=frame_count+1

pos=0.0d0
bond_index=0.0d0
neigh_list=0.0d0
no_neighbors=0.0d0



!do i=500000,500000
!charac_a ='store_'

       call addnumtostring(charac_a,i)
!write(*,*)charac_a
k3=0

       open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)j,charac_b,tempx,tempy,tempz
if(charac_b.eq.'Na')then
!if(charac_b.eq.'Na')then
k3=k3+1
pos(3*k3-2)=tempx
pos(3*k3-1)=tempy
pos(3*k3)=tempz
!write(*,*)k3,j

endif


enddo
close(083)


!----------------------------
! Mark all members of largest cluster
!----------------------------
do k = 1, npart
dx=pos(3*k-2)-x_out_cluster
dy=pos(3*k-1)-y_out_cluster
dz=pos(3*k)-z_out_cluster

dd=sqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
!write(*,*)dd
if (dd.lt.0.370d0) then
visited_actual_max(k)=1
!write(*,*)'hi'
endif

end do

!!!!!!!!!!!!!!!!!!!!!!!!!!!!Track all particles in the largest cluster in each frame !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!write(*,*)'hi'
do k=1,npart

if(visited_actual_max(k).eq.1)then
cluster_index_frame(k,frame_count)=1.0d0
instances_of_clustering(k)=instances_of_clustering(k)+ 1.0d0
frame_where_in_cluster(k,instances_of_clustering(k))=frame_count
!write(*,*)k,instances_of_clustering(k)

endif

enddo

enddo!!!!!! Time loop ends


!!!!!!!!!!!!! Calculate average over all particles and over all times !!!!!!!!!!!!!!!!!!!!!!!!!
!write(*,*)instances_of_clustering(202)
do j=1,npart
residence_time=1
!!!!!!Calculate residence times!!!!!!!!!!!!!
if (instances_of_clustering(j).gt.1.0d0)then
write(*,*)j,instances_of_clustering(j)
        do k=2,int(instances_of_clustering(j))
this_frame=frame_where_in_cluster(j,k)
prev_frame=frame_where_in_cluster(j,k-1)
if(this_frame.eq.(prev_frame+1))then
residence_time=residence_time+1


else
write(72,*)residence_time,residence_time

!write(*,*)residence_time

residence_time=1


endif
enddo

if (residence_time.gt.1) then
write(72,*) residence_time, residence_time
!if(j.eq.202)then
!write(*,*)instances_of_clustering(j),j,residence_time
!endif
endif

!if(j.eq.202)then
!write(*,*)i8,i7,j,residence_time
!endif

endif
!!!!!!!!!!!!!!!!!!!

!if(j.eq.202)then
!write(*,*)i8,i7,j,residence_time
!endif





enddo
enddo

enddo
close(72)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
