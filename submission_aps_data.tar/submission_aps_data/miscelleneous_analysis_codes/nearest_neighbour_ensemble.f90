program dist_nus

integer::i,ij,j,k1,k2,j1,k_count,i9
integer,parameter::npart=400
character(len=30) :: charac_a
character(len=2)::charac_b
character(len=3)::charac_d
real*8::tempx,tempy,tempz
real*8::pos(3*npart),dd_array(npart,npart)
real*8::dx,dy,dz,dd,dd_temp(npart-1)

!charac_a ='store_'


do i9=1,10

charac_d='r'
call addnumtostring(charac_d,i9)





charac_a =trim(charac_d)//'/store_'

write(*,*)charac_a



pos=0.0d0
do i=1000000,3900000,100000
!do i=500000,500000


charac_a =trim(charac_d)//'/store_'


dd_array=0.0d0
!charac_a ='store_'
k1=0
j=0
       call addnumtostring(charac_a,i)
     write(*,*)charac_a
       open(083,file=charac_a,status='unknown',form='formatted')
do j1=1,1867
!write(*,*)j1
read(083,*)charac_b,tempx,tempy,tempz

if(charac_b.eq.'Na')then
k1=k1+1
!write(*,*)j1,k1
pos(3*k1-2)=tempx
pos(3*k1-1)=tempy
pos(3*k1)=tempz
endif
enddo
close(083)
do k1=1,npart
!do k1=1,1
do k2=1,npart
if(k1.ne.k2)then
!do k2=k1+1,k1+1
if(pos(3*k1).ne.0)then
if(pos(3*k2).ne.0)then
dx=pos(3*k1-2)-pos(3*k2-2)
dy=pos(3*k1-1)-pos(3*k2-1)
dz=pos(3*k1)-pos(3*k2)
endif
endif
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
dd_array(k1,k2)=dd
!write(*,*)k1,k2,dd_array(k1,k2)
endif
enddo
enddo


do k1=1,npart
dd_temp=0.0d0
k_count=0
do k2=1,npart
if(k1.ne.k2)then
k_count=k_count+1
dd_temp(k_count)=dd_array(k1,k2)
!write(*,*)k_count,dd_temp(k_count)
endif
enddo

if(k1.ne.k2)then
write(84,*)minval(dd_temp),minval(dd_temp)
endif

enddo

enddo

enddo

contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
