program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,ii,j1,k_3
integer::k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15,k16,k17
integer::k18,k19,k20
integer,parameter::npart=7
character(len=30) :: charac_a
character(len=2)::charac_b
character(len=3)::charac_d
real*8::tempx,tempy,tempz,k_count
real*8,parameter::dist_thresh=1.50d0
real*8::pos(3*npart),dx,dy,dz,dd
!real*8::dx,dy,dz,dd
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer:: visited(npart),i9
real*8:: no_part_in_cluster(npart)
real*8::contact_prob(250),k_count_seg(250)!!!!!!!!!!!!! Change this for diff loop sizes!!!!!!!!!!!!!!
real*8::av_contact_prob(250),av_k_count_seg(250)!!!!!!!!!!!!!!!!!!!!!!!!!
!allocate(visited(npart),no_part_in_cluster(npart))

bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

av_contact_prob=0.0d0
av_k_count_seg=0.0d0


!pos=0.0d0
k1=0.0d0;k2=0.0d0;k3=0.0d0;k4=0.0d0;k5=0.0d0
k6=0.0d0;k7=0.0d0;k8=0.0d0;k9=0.0d0;k10=0.0d0

k11=0.0d0;k12=0.0d0;k13=0.0d0;k14=0.0d0;k15=0.0d0
k16=0.0d0;k17=0.0d0;k18=0.0d0;k19=0.0d0;k20=0.0d0



k_count=0.0d0

do i9=1,10

charac_d='r'
call addnumtostring(charac_d,i9)

!write(*,*)charac_d

do i=500000,3700000,100000

k_3=0
k_count=k_count+1.0d0

!do i=500000,500000
charac_a =trim(charac_d)//'/store_'

!write(*,*)charac_a
       call addnumtostring(charac_a,i)
! write(*,*)i,charac_a

       open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)tempx,tempy,tempz
if(charac_b.eq.'H')then
k_3=k_3+1
pos(3*k_3-2)=tempx
pos(3*k_3-1)=tempy
pos(3*k_3)=tempz
!write(*,*)k3
endif
enddo
!write(*,*)'hi'
!!!!!!!!!!!! Distribution of operon distances !!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

ii=1;j=2
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k1=k1+1.0d0
endif

ii=4;j=5
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k2=k2+1.0d0
endif

ii=2;j=3
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k3=k3+1.0d0
endif

ii=1;j=3
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k4=k4+1.0d0
endif

ii=3;j=4
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k5=k5+1.0d0
endif


ii=3;j=5
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k6=k6+1.0d0
endif


ii=1;j=2;j1=3
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
dx=pos(3*ii-2)-pos(3*j1-2)
dy=pos(3*ii-1)-pos(3*j1-1)
dz=pos(3*ii)-pos(3*j1)
dd2=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
        if(dd2.lt.dist_thresh)then
k7=k7+1.0d0
endif
endif

ii=2;j=4
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k8=k8+1.0d0
endif



ii=1;j=4
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k9=k9+1.0d0
endif


ii=2;j=5
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k10=k10+1.0d0
endif




ii=1;j=5
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k11=k11+1.0d0
endif

ii=1;j=7
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k12=k12+1.0d0
endif


ii=2;j=7
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k13=k13+1.0d0
endif

ii=3;j=7
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k14=k14+1.0d0
endif


ii=1;j=2;j1=4
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
dx=pos(3*ii-2)-pos(3*j1-2)
dy=pos(3*ii-1)-pos(3*j1-1)
dz=pos(3*ii)-pos(3*j1)
dd2=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
        if(dd2.lt.dist_thresh)then
k15=k15+1.0d0
endif
endif





ii=4;j=7
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k16=k16+1.0d0
endif





ii=1;j=2;j1=5
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
dx=pos(3*ii-2)-pos(3*j1-2)
dy=pos(3*ii-1)-pos(3*j1-1)
dz=pos(3*ii)-pos(3*j1)
dd2=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
        if(dd2.lt.dist_thresh)then
k17=k17+1.0d0
endif
endif

ii=5;j=7
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
k18=k18+1.0d0
endif


ii=3;j=4;j1=5
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
dx=pos(3*ii-2)-pos(3*j1-2)
dy=pos(3*ii-1)-pos(3*j1-1)
dz=pos(3*ii)-pos(3*j1)
dd2=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
        if(dd2.lt.dist_thresh)then
k19=k19+1.0d0
endif
endif



ii=1;j=2;j1=7
dx=pos(3*ii-2)-pos(3*j-2)
dy=pos(3*ii-1)-pos(3*j-1)
dz=pos(3*ii)-pos(3*j)
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
dx=pos(3*ii-2)-pos(3*j1-2)
dy=pos(3*ii-1)-pos(3*j1-1)
dz=pos(3*ii)-pos(3*j1)
dd2=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
if(dd.lt.dist_thresh)then
        if(dd2.lt.dist_thresh)then
k20=k20+1.0d0
endif
endif




close(083)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
enddo

enddo



write(21,*)1,k1/k_count
write(21,*)2,k2/k_count
write(21,*)3,k3/k_count
write(21,*)4,k4/k_count
write(21,*)5,k5/k_count
write(21,*)6,k6/k_count
write(21,*)7,k7/k_count
write(21,*)8,k8/k_count
write(21,*)9,k9/k_count
write(21,*)10,k10/k_count



write(21,*)11,k11/k_count
write(21,*)12,k12/k_count
write(21,*)13,k13/k_count
write(21,*)14,k14/k_count
write(21,*)15,k15/k_count
write(21,*)16,k16/k_count
write(21,*)17,k17/k_count
write(21,*)18,k18/k_count
write(21,*)19,k19/k_count
write(21,*)20,k20/k_count






contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
