program sort_cluster_probabilities

    implicit none
    integer, parameter :: max_configs = 2000
    character(len=20) :: config(max_configs)   ! store configurations like (1,2,3)
    real*8 :: prob(max_configs)
    integer :: n, i, j
    character(len=50) :: line
    integer :: ios
    character(len=20) :: tmp_config
    real*8 :: tmp_prob

    n = 0
    open(10, file="cluster_probabilities.txt", status="old", action="read")

    ! --------------------------------------------------------
    ! Read data line by line
    ! --------------------------------------------------------
    do
        read(10,'(A)', iostat=ios) line
        if (ios /= 0) exit
        n = n + 1
        read(line, *) config(n), prob(n)   ! list-directed read fixes extra column issue
    end do

    close(10)

    ! --------------------------------------------------------
    ! Sort in descending order of probability
    ! --------------------------------------------------------
    do i = 1, n-1
        do j = i+1, n
            if (prob(j) > prob(i)) then
                ! Swap probabilities
                tmp_prob = prob(i)
                prob(i) = prob(j)
                prob(j) = tmp_prob

                ! Swap configurations
                tmp_config = config(i)
                config(i) = config(j)
                config(j) = tmp_config
            end if
        end do
    end do

    ! --------------------------------------------------------
    ! Write sorted output (2 columns)
    ! --------------------------------------------------------
    open(20, file="cluster_probabilities_sorted.txt", status="unknown")
    do i = 1, n
        write(20,'(A,2X,F12.8)') trim(config(i)), prob(i)
    end do
    close(20)

    print *, 'Sorting complete. Output written to cluster_probabilities_sorted.txt'

end program sort_cluster_probabilities

