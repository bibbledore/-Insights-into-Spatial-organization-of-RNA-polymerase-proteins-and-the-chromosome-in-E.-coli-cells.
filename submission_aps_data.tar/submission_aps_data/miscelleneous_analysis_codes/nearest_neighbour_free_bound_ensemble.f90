program dist_nus

integer::i,ij,j,k1,k2,j1,k_count
integer,parameter::npart1=300,npart2=400
character(len=30) :: charac_a
character(len=2)::charac_b
character(len=3)::charac_d
real*8::tempx,tempy,tempz,pos2(3*npart2)
real*8::pos1(3*npart1),dd_array(npart1,npart2)
real*8::dx,dy,dz,dd,dd_temp(npart2)





do i9=1,10

charac_d='r'
call addnumtostring(charac_d,i9)





!charac_a ='store_'


charac_a =trim(charac_d)//'/store_'

write(*,*)charac_a



pos=0.0d0
do i=2580000,4570000,100000
!do i=500000,500000
dd_array=0.0d0
charac_a ='store_'
k1=0
k2=0
j=0
       call addnumtostring(charac_a,i)
       open(083,file=charac_a,status='unknown',form='formatted')
do j1=1,1867
read(083,*)charac_b,tempx,tempy,tempz

if(charac_b.eq.'N')then
k1=k1+1
!write(*,*)j1,k1
pos1(3*k1-2)=tempx
pos1(3*k1-1)=tempy
pos1(3*k1)=tempz
endif

if(charac_b.eq.'Na')then
k2=k2+1
!write(*,*)j1,k1
pos2(3*k2-2)=tempx
pos2(3*k2-1)=tempy
pos2(3*k2)=tempz
endif




enddo
close(083)
do k1=1,npart2
!do k1=1,1
do k2=1,npart2
!if(k1.ne.k2)then
!do k2=k1+1,k1+1
!if(pos(3*k1).ne.0)then
!if(pos(3*k2).ne.0)then
dx=pos1(3*k1-2)-pos2(3*k2-2)
dy=pos1(3*k1-1)-pos2(3*k2-1)
dz=pos1(3*k1)-pos2(3*k2)
!endif
!endif
dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
dd_array(k1,k2)=dd
!write(*,*)k1,k2,dd_array(k1,k2)
!endif
enddo
enddo


do k1=1,npart1
dd_temp=500.0d0
k_count=0
do k2=1,npart2
!if(k1.ne.k2)then
k_count=k_count+1
dd_temp(k_count)=dd_array(k1,k2)
!write(*,*)k_count,dd_temp(k_count)
!endif
enddo

!if(k1.ne.k2)then
write(84,*)minval(dd_temp),minval(dd_temp)
!endif

enddo

enddo

enddo

contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
