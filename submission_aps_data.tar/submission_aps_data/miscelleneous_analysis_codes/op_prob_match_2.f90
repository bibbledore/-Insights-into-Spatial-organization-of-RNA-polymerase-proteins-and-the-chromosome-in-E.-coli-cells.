program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,ii,j1,k_3,i2
integer::k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15,k16,k17
integer::k18,k19,k20,valid_core
integer,parameter::npart=7
character(len=30) :: charac_a
character(len=2)::charac_b
character(len=3)::charac_d
real*8::tempx,tempy,tempz,k_count
real*8,parameter::dist_thresh=1.50d0
real*8::pos(3*npart),dx,dy,dz,dd
!real*8::dx,dy,dz,dd
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer:: visited(npart),i9
real*8:: no_part_in_cluster(npart)
real*8::contact_prob(250),k_count_seg(250)!!!!!!!!!!!!! Change this for diff loop sizes!!!!!!!!!!!!!!
real*8::av_contact_prob(250),av_k_count_seg(250)!!!!!!!!!!!!!!!!!!!!!!!!!
logical :: is_quad,is_doublet, is_triplet, is_quadruplet, is_pentuplet
real*8::d1,dx1,dy1,dz1,d2,dx2,dy2,dz2,d3,dx3,dy3,dz3,d4,dx4,dy4,dz4,d6,dx6,dy6,dz6
real*8::d7,dx7,dy7,dz7
!allocate(visited(npart),no_part_in_cluster(npart))

bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

av_contact_prob=0.0d0
av_k_count_seg=0.0d0


!pos=0.0d0
k1=0.0d0;k2=0.0d0;k3=0.0d0;k4=0.0d0;k5=0.0d0
k6=0.0d0;k7=0.0d0;k8=0.0d0;k9=0.0d0;k10=0.0d0

k11=0.0d0;k12=0.0d0;k13=0.0d0;k14=0.0d0;k15=0.0d0
k16=0.0d0;k17=0.0d0;k18=0.0d0;k19=0.0d0;k20=0.0d0



k_count=0.0d0

do i9=1,10

charac_d='r'
call addnumtostring(charac_d,i9)

!write(*,*)charac_d

do i=500000,3700000,100000

k_3=0
k_count=k_count+1.0d0

!do i=500000,500000
charac_a =trim(charac_d)//'/store_'

!write(*,*)charac_a
       call addnumtostring(charac_a,i)
! write(*,*)i,charac_a

       open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)tempx,tempy,tempz
if(charac_b.eq.'H')then
k_3=k_3+1
pos(3*k_3-2)=tempx
pos(3*k_3-1)=tempy
pos(3*k_3)=tempz
!write(*,*)k3
endif
enddo
!write(*,*)'hi'
!!!!!!!!!!!! Distribution of operon distances !!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


do i1=1,npart
  do i2=1,npart
    dx = pos(3*i1-2) - pos(3*i2-2)
    dy = pos(3*i1-1) - pos(3*i2-1)
    dz = pos(3*i1)   - pos(3*i2)
    dd = dsqrt(dx**2 + dy**2 + dz**2)
    if(i1.ne.i2) then
      if(dd.lt.dist_thresh) then
!              if(i1.eq.1.and.i2.eq.2.or.i2.eq.1.and.i1.eq.2)then
if( (i1.eq.1 .and. i2.eq.2) .or. (i1.eq.2 .and. i2.eq.1) ) then 
is_doublet = .true.
        do j=1,npart
          if(j.ne.i1 .and. j.ne.i2) then
            ! distance j--i1
            dx1 = pos(3*j-2) - pos(3*i1-2)
            dy1 = pos(3*j-1) - pos(3*i1-1)
            dz1 = pos(3*j)   - pos(3*i1)
            d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
            if(d1.lt.dist_thresh) then
              is_doublet = .false.
            end if
            ! distance j--i2
            dx2 = pos(3*j-2) - pos(3*i2-2)
            dy2 = pos(3*j-1) - pos(3*i2-1)
            dz2 = pos(3*j)   - pos(3*i2)
            d2 = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
            if(d2.lt.dist_thresh) then
              is_doublet = .false.
            end if
          end if
        end do
        if(is_doublet) then
          k1 = k1 + 1.0d0
        end if
endif
      end if
    end if
  end do
end do


is_doublet = .false.

do i1=1,npart
  do i2=1,npart
    dx = pos(3*i1-2) - pos(3*i2-2)
    dy = pos(3*i1-1) - pos(3*i2-1)
    dz = pos(3*i1)   - pos(3*i2)
    dd = dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
    if(i1.ne.i2) then
      if(dd.lt.dist_thresh) then
!              if(i1.eq.1.and.i2.eq.2.or.i2.eq.1.and.i1.eq.2)then
if( (i1.eq.1 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.1) ) then
is_doublet = .true.
        do j=1,npart
          if(j.ne.i1 .and. j.ne.i2) then
            ! distance j--i1
            dx1 = pos(3*j-2) - pos(3*i1-2)
            dy1 = pos(3*j-1) - pos(3*i1-1)
            dz1 = pos(3*j)   - pos(3*i1)
            d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
            if(d1.lt.dist_thresh) then
              is_doublet = .false.
            end if
            ! distance j--i2
            dx2 = pos(3*j-2) - pos(3*i2-2)
            dy2 = pos(3*j-1) - pos(3*i2-1)
            dz2 = pos(3*j)   - pos(3*i2)
            d2 = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
            if(d2.lt.dist_thresh) then
              is_doublet = .false.
            end if
          end if
        end do
        if(is_doublet) then
          k2 = k2 + 1.0d0
        end if
endif
      end if
    end if
  end do
end do




is_doublet = .false.
do i1=1,npart
  do i2=1,npart
    dx = pos(3*i1-2) - pos(3*i2-2)
    dy = pos(3*i1-1) - pos(3*i2-1)
    dz = pos(3*i1)   - pos(3*i2)
    dd = dsqrt(dx**2 + dy**2 + dz**2)
    if(i1.ne.i2) then
      if(dd.lt.dist_thresh) then
!              if(i1.eq.1.and.i2.eq.2.or.i2.eq.1.and.i1.eq.2)then
if( (i1.eq.5 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.5) ) then
is_doublet = .true.
        do j=1,npart
          if(j.ne.i1 .and. j.ne.i2) then
            ! distance j--i1
            dx1 = pos(3*j-2) - pos(3*i1-2)
            dy1 = pos(3*j-1) - pos(3*i1-1)
            dz1 = pos(3*j)   - pos(3*i1)
            d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
            if(d1.lt.dist_thresh) then
              is_doublet = .false.
            end if
            ! distance j--i2
            dx2 = pos(3*j-2) - pos(3*i2-2)
            dy2 = pos(3*j-1) - pos(3*i2-1)
            dz2 = pos(3*j)   - pos(3*i2)
            d2 = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
            if(d2.lt.dist_thresh) then
              is_doublet = .false.
            end if
          end if
        end do
        if(is_doublet) then
          k3 = k3 + 1.0d0
        end if
endif
      end if
    end if
  end do
end do





is_triplet = .false.
do i1=1,npart
  do i2=1,npart
    ! Only check the core required connections: 2-3, 2-5, 3-5
    if( ( (i1.eq.2 .and. i2.eq.3) .or. (i1.eq.3 .and. i2.eq.2) ) .or. &
        ( (i1.eq.2 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.2) ) .or. &
        ( (i1.eq.3 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.3) ) ) then
      ! Compute distance
      dx = pos(3*i1-2) - pos(3*i2-2)
      dy = pos(3*i1-1) - pos(3*i2-1)
      dz = pos(3*i1)   - pos(3*i2)
      dd = dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
      if(dd.lt.dist_thresh) then
        valid_core = valid_core + 1      ! count how many of the 3 required edges are present
      end if
    end if
  end do
end do
! Now check if all 3 required edges exist
if(valid_core.eq.6) then
   is_triplet = .true.
else
   is_triplet = .false.
end if
! If core is valid, check for contamination from other points
if(is_triplet) then
  do j = 1, npart
    if(j.ne.2 .and. j.ne.3 .and. j.ne.5) then
      ! Check j against 2
      dx1 = pos(3*j-2) - pos(3*2-2)
      dy1 = pos(3*j-1) - pos(3*2-1)
      dz1 = pos(3*j)   - pos(3*2)
      d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
      if(d1.lt.dist_thresh) is_triplet = .false.
      ! Check j against 3
      dx2 = pos(3*j-2) - pos(3*3-2)
      dy2 = pos(3*j-1) - pos(3*3-1)
      dz2 = pos(3*j)   - pos(3*3)
      d2 = dsqrt(dx2**2 + dy2**2 + dz2**2)
      if(d2.lt.dist_thresh) is_triplet = .false.
      ! Check j against 5
      dx3 = pos(3*j-2) - pos(3*5-2)
      dy3 = pos(3*j-1) - pos(3*5-1)
      dz3 = pos(3*j)   - pos(3*5)
      d3 = dsqrt(dx3**2.0d0 + dy3**2.0d0 + dz3**2.0d0)
      if(d3.lt.dist_thresh) is_triplet = .false.
    end if
  end do
end if
if(is_triplet) then
   k4 = k4 + 1.0d0   ! Or whatever counter is for config 3
end if



! ------------------ Quadruplet (2,3,4,5) ------------------
valid_core = 0
is_quad = .false.

do i1=1,npart
  do i2=1,npart

    ! Check only the required edges among 2,3,4,5
    if( ((i1.eq.2 .and. i2.eq.3) .or. (i1.eq.3 .and. i2.eq.2)) .or. &
        ((i1.eq.2 .and. i2.eq.4) .or. (i1.eq.4 .and. i2.eq.2)) .or. &
        ((i1.eq.2 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.2)) .or. &
        ((i1.eq.3 .and. i2.eq.4) .or. (i1.eq.4 .and. i2.eq.3)) .or. &
        ((i1.eq.3 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.3)) .or. &
        ((i1.eq.4 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.4)) ) then

      dx = pos(3*i1-2) - pos(3*i2-2)
      dy = pos(3*i1-1) - pos(3*i2-1)
      dz = pos(3*i1)   - pos(3*i2)
      dd = dsqrt(dx**2 + dy**2 + dz**2)

      if(dd.lt.dist_thresh) then
        valid_core = valid_core + 1
      end if

    end if
  end do
end do

! Each of 6 edges is counted twice in full i1,i2 loop → valid_core = 12
if(valid_core.eq.12) then
  is_quad = .true.
else
  is_quad = .false.
end if

! Check no contamination from other particles (1,6,7)
if(is_quad) then
  do j=1,npart
    if(j.ne.2 .and. j.ne.3 .and. j.ne.4 .and. j.ne.5) then

      ! Check against 2
      dx1 = pos(3*j-2) - pos(3*2-2)
      dy1 = pos(3*j-1) - pos(3*2-1)
      dz1 = pos(3*j)   - pos(3*2)
      d1 = dsqrt(dx1**2 + dy1**2 + dz1**2)
      if(d1.lt.dist_thresh) is_quad = .false.

      ! Check against 3
      dx2 = pos(3*j-2) - pos(3*3-2)
      dy2 = pos(3*j-1) - pos(3*3-1)
      dz2 = pos(3*j)   - pos(3*3)
      d2 = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
      if(d2.lt.dist_thresh) is_quad = .false.

      ! Check against 4
      dx3 = pos(3*j-2) - pos(3*4-2)
      dy3 = pos(3*j-1) - pos(3*4-1)
      dz3 = pos(3*j)   - pos(3*4)
      d3 = dsqrt(dx3**2.0d0 + dy3**2.0d0 + dz3**2.0d0)
      if(d3.lt.dist_thresh) is_quad = .false.

      ! Check against 5
      dx4 = pos(3*j-2) - pos(3*5-2)
      dy4 = pos(3*j-1) - pos(3*5-1)
      dz4 = pos(3*j)   - pos(3*5)
      d4 = dsqrt(dx4**2.0d0 + dy4**2.0d0 + dz4**2.0d0)
      if(d4.lt.dist_thresh) is_quad = .false.

    end if
  end do
end if

! Final count
if(is_quad) then
  k5 = k5 + 1.0d0
end if
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

is_triplet = .false.
do i1=1,npart
  do i2=1,npart
if( ((i1.eq.1 .and. i2.eq.3) .or. (i1.eq.3 .and. i2.eq.1)) .or. &
    ((i1.eq.1 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.1)) .or. &
    ((i1.eq.3 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.3)) ) then
 ! Compute distance
      dx = pos(3*i1-2) - pos(3*i2-2)
      dy = pos(3*i1-1) - pos(3*i2-1)
      dz = pos(3*i1)   - pos(3*i2)
      dd = dsqrt(dx**2 + dy**2 + dz**2)
      if(dd.lt.dist_thresh) then
        valid_core = valid_core + 1      ! count how many of the 3 required edges are present
      end if
    end if
  end do
end do
! Now check if all 3 required edges exist
if(valid_core.eq.6) then
   is_triplet = .true.
else
   is_triplet = .false.
end if
! If core is valid, check for contamination from other points
if(is_triplet) then
  do j = 1, npart
    if(j.ne.1 .and. j.ne.3 .and. j.ne.6) then
      ! Check j against 2
      dx1 = pos(3*j-2) - pos(3*1-2)
      dy1 = pos(3*j-1) - pos(3*1-1)
      dz1 = pos(3*j)   - pos(3*1)
      d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
      if(d1.lt.dist_thresh) is_triplet = .false.
      ! Check j against 3
      dx2 = pos(3*j-2) - pos(3*3-2)
      dy2 = pos(3*j-1) - pos(3*3-1)
      dz2 = pos(3*j)   - pos(3*3)
      d2 = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
      if(d2.lt.dist_thresh) is_triplet = .false.
      ! Check j against 5
      dx3 = pos(3*j-2) - pos(3*6-2)
      dy3 = pos(3*j-1) - pos(3*6-1)
      dz3 = pos(3*j)   - pos(3*6)
      d3 = dsqrt(dx3**2.0d0 + dy3**2.0d0 + dz3**2.0d0)
   if(d3.lt.dist_thresh) is_triplet = .false.
    end if
  end do
end if
if(is_triplet) then
   k6 = k6 + 1.0d0   ! Or whatever counter is for config 3
end if



!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
is_triplet = .false.
do i1=1,npart
  do i2=1,npart
 
  if( ((i1.eq.1 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.1)) .or. &
    ((i1.eq.1 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.1)) .or. &
    ((i1.eq.5 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.5)) ) then
  ! Compute distance
      dx = pos(3*i1-2) - pos(3*i2-2)
      dy = pos(3*i1-1) - pos(3*i2-1)
      dz = pos(3*i1)   - pos(3*i2)
      dd = dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
      if(dd.lt.dist_thresh) then
        valid_core = valid_core + 1      ! count how many of the 3 required edges are present
      end if
    end if
  end do
end do
! Now check if all 3 required edges exist
if(valid_core.eq.6) then
   is_triplet = .true.
else
   is_triplet = .false.
end if
! If core is valid, check for contamination from other points
if(is_triplet) then
  do j = 1, npart
    if(j.ne.1 .and. j.ne.5 .and. j.ne.6) then
      ! Check j against 2
      dx1 = pos(3*j-2) - pos(3*1-2)
      dy1 = pos(3*j-1) - pos(3*1-1)
      dz1 = pos(3*j)   - pos(3*1)
      d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
      if(d1.lt.dist_thresh) is_triplet = .false.
      ! Check j against 3
      dx2 = pos(3*j-2) - pos(3*5-2)
      dy2 = pos(3*j-1) - pos(3*5-1)
      dz2 = pos(3*j)   - pos(3*5)
      d2 = dsqrt(dx2**2 + dy2**2 + dz2**2)
      if(d2.lt.dist_thresh) is_triplet = .false.
      ! Check j against 5
      dx3 = pos(3*j-2) - pos(3*6-2)
      dy3 = pos(3*j-1) - pos(3*6-1)
      dz3 = pos(3*j)   - pos(3*6)
      d3 = dsqrt(dx3**2.0d0 + dy3**2.0d0 + dz3**2.0d0)
   if(d3.lt.dist_thresh) is_triplet = .false.
   end if
  end do
end if
if(is_triplet) then
   k7 = k7 + 1.0d0   ! Or whatever counter is for config 3
end if

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
is_triplet = .false.
do i1=1,npart
  do i2=1,npart

if( ((i1.eq.5 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.5)) .or. &
    ((i1.eq.5 .and. i2.eq.7) .or. (i1.eq.7 .and. i2.eq.5)) .or. &
    ((i1.eq.6 .and. i2.eq.7) .or. (i1.eq.7 .and. i2.eq.6)) ) then
  ! Compute distance
      dx = pos(3*i1-2) - pos(3*i2-2)
      dy = pos(3*i1-1) - pos(3*i2-1)
      dz = pos(3*i1)   - pos(3*i2)
      dd = dsqrt(dx**2 + dy**2 + dz**2)
      if(dd.lt.dist_thresh) then
        valid_core = valid_core + 1      ! count how many of the 3 required edges are present
      end if
    end if
  end do
end do
! Now check if all 3 required edges exist
if(valid_core.eq.6) then
   is_triplet = .true.
else
   is_triplet = .false.
end if
! If core is valid, check for contamination from other points
if(is_triplet) then
  do j = 1, npart
    if(j.ne.5 .and. j.ne.6 .and. j.ne.7) then
      ! Check j against 2
      dx1 = pos(3*j-2) - pos(3*5-2)
      dy1 = pos(3*j-1) - pos(3*5-1)
      dz1 = pos(3*j)   - pos(3*5)
      d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
      if(d1.lt.dist_thresh) is_triplet = .false.
      ! Check j against 3
      dx2 = pos(3*j-2) - pos(3*6-2)
      dy2 = pos(3*j-1) - pos(3*6-1)
      dz2 = pos(3*j)   - pos(3*6)
      d2 = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
      if(d2.lt.dist_thresh) is_triplet = .false.
 dx3 = pos(3*j-2) - pos(3*7-2)
      dy3 = pos(3*j-1) - pos(3*7-1)
      dz3 = pos(3*j)   - pos(3*7)
      d3 = dsqrt(dx3**2.0d0 + dy3**2.0d0 + dz3**2.0d0)
   if(d3.lt.dist_thresh) is_triplet = .false.
   end if
  end do
end if
if(is_triplet) then
   k8 = k8 + 1.0d0   ! Or whatever counter is for config 3
end if
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
valid_core = 0
is_quad = .false.

do i1=1,npart
  do i2=1,npart

    ! Check only the required edges among 2,3,4,5
if( ((i1.eq.1 .and. i2.eq.4) .or. (i1.eq.4 .and. i2.eq.1)) .or. &
    ((i1.eq.1 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.1)) .or. &
    ((i1.eq.1 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.1)) .or. &
    ((i1.eq.4 .and. i2.eq.5) .or. (i1.eq.5 .and. i2.eq.4)) .or. &
    ((i1.eq.4 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.4)) .or. &
    ((i1.eq.5 .and. i2.eq.6) .or. (i1.eq.6 .and. i2.eq.5)) ) then



      dx = pos(3*i1-2) - pos(3*i2-2)
      dy = pos(3*i1-1) - pos(3*i2-1)
      dz = pos(3*i1)   - pos(3*i2)
      dd = dsqrt(dx**2 + dy**2 + dz**2)

      if(dd.lt.dist_thresh) then
        valid_core = valid_core + 1
      end if

    end if
  end do
end do
! Each of 6 edges is counted twice in full i1,i2 loop → valid_core = 12
if(valid_core.eq.12) then
  is_quad = .true.
else
  is_quad = .false.
end if

! Check no contamination from other particles (1,6,7)
if(is_quad) then
  do j=1,npart
    if(j.ne.1 .and. j.ne.4 .and. j.ne.5 .and. j.ne.6) then

      ! Check against 2
      dx1 = pos(3*j-2) - pos(3*1-2)
      dy1 = pos(3*j-1) - pos(3*1-1)
      dz1 = pos(3*j)   - pos(3*1)
      d1 = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
      if(d1.lt.dist_thresh) is_quad = .false.

      ! Check against 3
      dx2 = pos(3*j-2) - pos(3*4-2)
      dy2 = pos(3*j-1) - pos(3*4-1)
      dz2 = pos(3*j)   - pos(3*4)
      d2 = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
      if(d2.lt.dist_thresh) is_quad = .false.

      ! Check against 4
      dx3 = pos(3*j-2) - pos(3*5-2)
      dy3 = pos(3*j-1) - pos(3*5-1)
      dz3 = pos(3*j)   - pos(3*5)
      d3 = dsqrt(dx3**2.0d0 + dy3**2.0d0 + dz3**2.0d0)
      if(d3.lt.dist_thresh) is_quad = .false.

      ! Check against 5
      dx4 = pos(3*j-2) - pos(3*6-2)
      dy4 = pos(3*j-1) - pos(3*6-1)
      dz4 = pos(3*j)   - pos(3*6)
      d4 = dsqrt(dx4**2.0d0 + dy4**2.0d0 + dz4**2.0d0)
      if(d4.lt.dist_thresh) is_quad = .false.

    end if
  end do
end if

! Final count
if(is_quad) then
  k9 = k9 + 1.0d0
end if
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



! ---------------- PENTUPLET (1,2,3,4,6) DETECTION BLOCK ----------------
! Initializes counter for required distinct pairs
valid_core = 0

! Loop over all ordered pairs but count each unordered pair only once (i1<i2)
do i1 = 1, npart
  do i2 = 1, npart

    if (i1 < i2) then
      ! check whether the unordered pair (i1,i2) is one of the 10 required pairs
      if ( (i1.eq.1 .and. i2.eq.2) .or. (i1.eq.1 .and. i2.eq.3) .or. &
           (i1.eq.1 .and. i2.eq.4) .or. (i1.eq.1 .and. i2.eq.6) .or. &
           (i1.eq.2 .and. i2.eq.3) .or. (i1.eq.2 .and. i2.eq.4) .or. &
           (i1.eq.2 .and. i2.eq.6) .or. (i1.eq.3 .and. i2.eq.4) .or. &
           (i1.eq.3 .and. i2.eq.6) .or. (i1.eq.4 .and. i2.eq.6) ) then

        dx = pos(3*i1-2) - pos(3*i2-2)
        dy = pos(3*i1-1) - pos(3*i2-1)
        dz = pos(3*i1)   - pos(3*i2)
        dd = dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)

        if (dd .lt. dist_thresh) then
          valid_core = valid_core + 1
        end if

      end if
    end if

  end do
end do

! If all 10 distinct pairs are close, check isolation (no extra particle close to any of the five)
if (valid_core .eq. 10) then

  is_pentuplet = .true.

  do j = 1, npart
    if (j.ne.1 .and. j.ne.2 .and. j.ne.3 .and. j.ne.4 .and. j.ne.6) then

      ! distance j--1
      dx1 = pos(3*j-2) - pos(3*1-2)
      dy1 = pos(3*j-1) - pos(3*1-1)
      dz1 = pos(3*j)   - pos(3*1)
      d1  = dsqrt(dx1**2.0d0 + dy1**2.0d0 + dz1**2.0d0)
      if (d1 .lt. dist_thresh) is_pentuplet = .false.

      ! distance j--2
      dx2 = pos(3*j-2) - pos(3*2-2)
      dy2 = pos(3*j-1) - pos(3*2-1)
      dz2 = pos(3*j)   - pos(3*2)
      d2  = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
      if (d2 .lt. dist_thresh) is_pentuplet = .false.

      ! distance j--3
      dx3 = pos(3*j-2) - pos(3*3-2)
      dy3 = pos(3*j-1) - pos(3*3-1)
      dz3 = pos(3*j)   - pos(3*3)
      d3  = dsqrt(dx3**2.0d0 + dy3**2.0d0 + dz3**2.0d0)
      if (d3 .lt. dist_thresh) is_pentuplet = .false.

      ! distance j--4
      dx4 = pos(3*j-2) - pos(3*4-2)
      dy4 = pos(3*j-1) - pos(3*4-1)
      dz4 = pos(3*j)   - pos(3*4)
      d4  = dsqrt(dx4**2.0d0 + dy4**2.0d0 + dz4**2.0d0)
      if (d4 .lt. dist_thresh) is_pentuplet = .false.

      ! distance j--6
      dx6 = pos(3*j-2) - pos(3*6-2)
      dy6 = pos(3*j-1) - pos(3*6-1)
      dz6 = pos(3*j)   - pos(3*6)
      d6  = dsqrt(dx6**2.0d0 + dy6**2.0d0 + dz6**2.0d0)
      if (d6 .lt. dist_thresh) is_pentuplet = .false.

    end if
  end do

  if (is_pentuplet) then
    k10 = k10 + 1.0d0
  end if

end if
! ---------------- END PENTUPLET BLOCK ----------------




! ---------------- QUADRUPLET (2,4,6,7) DETECTION BLOCK ----------------
! Initialize counter for required distinct pairs
valid_core = 0

! Loop over all ordered pairs but count each unordered pair only once (i1<i2)
do i1 = 1, npart
  do i2 = 1, npart

    if (i1 < i2) then
      ! check whether the unordered pair (i1,i2) is one of the 6 required pairs
      if ( (i1.eq.2 .and. i2.eq.4) .or. (i1.eq.2 .and. i2.eq.6) .or. &
           (i1.eq.2 .and. i2.eq.7) .or. (i1.eq.4 .and. i2.eq.6) .or. &
           (i1.eq.4 .and. i2.eq.7) .or. (i1.eq.6 .and. i2.eq.7) ) then

        dx = pos(3*i1-2) - pos(3*i2-2)
        dy = pos(3*i1-1) - pos(3*i2-1)
        dz = pos(3*i1)   - pos(3*i2)
        dd = dsqrt(dx**2 + dy**2 + dz**2)

        if (dd .lt. dist_thresh) then
          valid_core = valid_core + 1
        end if

      end if
    end if

  end do
end do

! If all 6 distinct pairs are close, check isolation (no extra particle near any of the four)
if (valid_core .eq. 6) then

  is_quadruplet = .true.

  do j = 1, npart
    if (j.ne.2 .and. j.ne.4 .and. j.ne.6 .and. j.ne.7) then

      ! distance j--2
      dx2 = pos(3*j-2) - pos(3*2-2)
      dy2 = pos(3*j-1) - pos(3*2-1)
      dz2 = pos(3*j)   - pos(3*2)
      d2  = dsqrt(dx2**2.0d0 + dy2**2.0d0 + dz2**2.0d0)
      if (d2 .lt. dist_thresh) is_quadruplet = .false.

      ! distance j--4
      dx4 = pos(3*j-2) - pos(3*4-2)
      dy4 = pos(3*j-1) - pos(3*4-1)
      dz4 = pos(3*j)   - pos(3*4)
      d4  = dsqrt(dx4**2.0d0 + dy4**2.0d0 + dz4**2.0d0)
      if (d4 .lt. dist_thresh) is_quadruplet = .false.

      ! distance j--6
      dx6 = pos(3*j-2) - pos(3*6-2)
      dy6 = pos(3*j-1) - pos(3*6-1)
      dz6 = pos(3*j)   - pos(3*6)
      d6  = dsqrt(dx6**2.0d0 + dy6**2.0d0 + dz6**2.0d0)
      if (d6 .lt. dist_thresh) is_quadruplet = .false.

      ! distance j--7
      dx7 = pos(3*j-2) - pos(3*7-2)
      dy7 = pos(3*j-1) - pos(3*7-1)
      dz7 = pos(3*j)   - pos(3*7)
      d7  = dsqrt(dx7**2.0d0 + dy7**2.0d0 + dz7**2.0d0)
      if (d7 .lt. dist_thresh) is_quadruplet = .false.

    end if
  end do

  if (is_quadruplet) then
    k11 = k11 + 1.0d0
  end if

end if
! ---------------- END QUADRUPLET BLOCK ----------------


! ---------------- PENTUPLET (2,3,4,6,7) DETECTION BLOCK ----------------
valid_core = 0

! Loop over all unordered pairs (i1<i2)
do i1 = 1, npart
  do i2 = 1, npart

    if (i1 < i2) then
      ! check if (i1,i2) is one of the 10 pairs among {2,3,4,6,7}
      if ( (i1.eq.2 .and. i2.eq.3) .or. (i1.eq.2 .and. i2.eq.4) .or. &
           (i1.eq.2 .and. i2.eq.6) .or. (i1.eq.2 .and. i2.eq.7) .or. &
           (i1.eq.3 .and. i2.eq.4) .or. (i1.eq.3 .and. i2.eq.6) .or. &
           (i1.eq.3 .and. i2.eq.7) .or. (i1.eq.4 .and. i2.eq.6) .or. &
           (i1.eq.4 .and. i2.eq.7) .or. (i1.eq.6 .and. i2.eq.7) ) then

        dx = pos(3*i1-2) - pos(3*i2-2)
        dy = pos(3*i1-1) - pos(3*i2-1)
        dz = pos(3*i1)   - pos(3*i2)
        dd = dsqrt(dx**2 + dy**2 + dz**2)

        if (dd .lt. dist_thresh) valid_core = valid_core + 1

      end if
    end if

  end do
end do

! Check that all 10 pairs are close
if (valid_core .eq. 10) then

  is_pentuplet = .true.

  do j = 1, npart
    if (j.ne.2 .and. j.ne.3 .and. j.ne.4 .and. j.ne.6 .and. j.ne.7) then

      ! distance j--2
      dx2 = pos(3*j-2) - pos(3*2-2)
      dy2 = pos(3*j-1) - pos(3*2-1)
      dz2 = pos(3*j)   - pos(3*2)
      if (dsqrt(dx2**2 + dy2**2 + dz2**2) < dist_thresh) is_pentuplet = .false.

      ! distance j--3
      dx3 = pos(3*j-2) - pos(3*3-2)
      dy3 = pos(3*j-1) - pos(3*3-1)
      dz3 = pos(3*j)   - pos(3*3)
      if (dsqrt(dx3**2 + dy3**2 + dz3**2) < dist_thresh) is_pentuplet = .false.

      ! distance j--4
      dx4 = pos(3*j-2) - pos(3*4-2)
      dy4 = pos(3*j-1) - pos(3*4-1)
      dz4 = pos(3*j)   - pos(3*4)
      if (dsqrt(dx4**2 + dy4**2 + dz4**2) < dist_thresh) is_pentuplet = .false.

      ! distance j--6
      dx6 = pos(3*j-2) - pos(3*6-2)
      dy6 = pos(3*j-1) - pos(3*6-1)
      dz6 = pos(3*j)   - pos(3*6)
      if (dsqrt(dx6**2 + dy6**2 + dz6**2) < dist_thresh) is_pentuplet = .false.

      ! distance j--7
      dx7 = pos(3*j-2) - pos(3*7-2)
      dy7 = pos(3*j-1) - pos(3*7-1)
      dz7 = pos(3*j)   - pos(3*7)
      if (dsqrt(dx7**2 + dy7**2 + dz7**2) < dist_thresh) is_pentuplet = .false.

    end if
  end do

  if (is_pentuplet) then
    k12 = k12 + 1.0d0
  end if

end if
! ---------------- END PENTUPLET BLOCK ----------------






!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!







close(083)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
enddo

enddo



write(21,*)1,k1/(2.0d0*k_count)
write(21,*)2,k2/(2.0d0*k_count)
write(21,*)3,k3/(2.0d0*k_count)
write(21,*)4,k4/(2.0d0*k_count)
write(21,*)5,k5/(2.0d0*k_count)
write(21,*)6,k6/(2.0d0*k_count)
write(21,*)7,k7/(2.0d0*k_count)
write(21,*)8,k8/(2.0d0*k_count)
write(21,*)9,k9/(2.0d0*k_count)
write(21,*)10,k10/k_count
write(21,*)11,k11/k_count
write(21,*)12,k12/k_count



!write(21,*)13,k13/k_count
!write(21,*)14,k14/k_count
!write(21,*)15,k15/k_count
!write(21,*)16,k16/k_count
!write(21,*)17,k17/k_count
!write(21,*)18,k18/k_count
!write(21,*)19,k19/k_count
!write(21,*)20,k20/k_count






contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
