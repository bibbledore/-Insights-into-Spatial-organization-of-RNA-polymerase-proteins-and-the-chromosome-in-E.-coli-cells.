program sort_cluster_probabilities
    implicit none
    integer, parameter :: max_configs = 2000
    character(len=20) :: config(max_configs)
    real*8 :: prob(max_configs)
    integer :: n, i, j, ios, p_start
    character(len=100) :: line, prob_str
    character(len=20) :: tmp_config
    real*8 :: tmp_prob

    n = 0
    open(10, file="cluster_probabilities.txt", status="old", action="read")

    ! ---------------- Read each line ----------------
    do
        read(10,'(A)', iostat=ios) line
        if (ios /= 0) exit
        n = n + 1

        ! find where the probability starts (after the closing parenthesis)
        p_start = index(line, ')') + 1
        if (p_start <= 1) then
            print *, 'Error parsing line:', trim(line)
            stop
        end if

        config(n) = adjustl(line(1:p_start))  ! include closing parenthesis
        prob_str = adjustl(line(p_start+1:))
        read(prob_str, *) prob(n)            ! convert to real
    end do

    close(10)

    ! ---------------- Sort in descending order ----------------
    do i = 1, n-1
        do j = i+1, n
            if (prob(j) > prob(i)) then
                tmp_prob = prob(i)
                prob(i) = prob(j)
                prob(j) = tmp_prob

                tmp_config = config(i)
                config(i) = config(j)
                config(j) = tmp_config
            end if
        end do
    end do

    ! ---------------- Write sorted output ----------------
    open(20, file="cluster_probabilities_sorted.txt", status="unknown")
    do i = 1, n
   !     write(20,'(A,2X,F12.8)') trim(config(i)), prob(i)
   write(20,*) i, prob(i)
 
  
   end do
    close(20)

    print *, 'Sorting complete. Output written to cluster_probabilities_sorted.txt'

end program sort_cluster_probabilities

