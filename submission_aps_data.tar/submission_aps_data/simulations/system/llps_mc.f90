module parameters
implicit none

integer, parameter :: n_monomer=460,niter=800000000,rate_rep=2000,call_neigh=10
integer, parameter :: eq_over=0, niter_eq=80000000,topo_rate=1000,npart_rnap=700
integer, parameter :: n_trajectory=1000,kbt=1,npart_nus=300,npart_free_nus=400
real*8, parameter :: kappa= 100.0d0,box_size=1000.0d0 ! SPRING POTENTIAL kappa for mother chain
real*8, parameter :: kappa_rep=1.0d0*kappa
real*8,parameter ::no_rnap_per_operon=42.0d0,rnap_poly_bind_switch=1.0d0,no_nus_per_rnap=1.0d0,rnap_ev_interaction_switch=0.0d0
real*8,parameter:: dist_threshold_bind_nus_rnap=0.50d0
integer ::no_neighbour(2*n_monomer),neigh_list(2*n_monomer,2*n_monomer),rep_site ! note : made neighlist array smaller: efficiency
integer::neigh_list_nus(2*npart_nus,2*npart_nus),no_neighbour_nus(2*npart_nus)
integer::neigh_list_free_nus(2*npart_free_nus,2*npart_free_nus),no_neighbour_free_nus(2*npart_free_nus)
integer::neigh_list_free_bound_nus(2*npart_free_nus,2*npart_nus),no_neighbour_free_bound_nus(2*npart_free_nus)
real*8, parameter :: delta = 0.30d0 ! TRIAL STEP AMPLITUDE for mother
!real*8, parameter :: delta_rep=1.0d0*delta
real*8, parameter :: ll0=1.0d0,llz= box_size ! RADIUS OF PARTICLE
!real*8, parameter :: rc= (2.0d0)**(1.0d0/6.0d0)*sigma ! radius cutoff ! AC.
real*8, parameter ::  eps = 10.0d0  ! epsilon of Lennard Jones
!real*8, parameter :: vc = eps*((sigma/rc)**12 - (sigma/rc)**6) 
!real*8, parameter :: fc= eps*(12.0d0*(sigma/rc)**13.0d0 - 6.0d0*(sigma/rc)**7.0d0 )
real*8, parameter :: rskin=4.50d0,confine=1.0d0,nus_bond_max_dist=20.0d0
real*8,parameter ::cyil_rad=3.50d0,sigma_rnap=0.10d0
integer,parameter::seg_size=5!!Actve segment
integer,parameter::seed=316534
integer,parameter::poly_ev_switch=0
real*8, parameter :: dist_threshold_bind_rnap_poly=1.0d0
real*8,parameter ::niter_nus_threshold=500000,niter_rnap_threshold=3000,niter_nus_att_threshold=400000
real*8,parameter :: kappa_operon=100.0d0,kappa_nus=100.0d0
integer,parameter::rrn_operon1=1,rrn_operon2=3,rrn_operon3=12,rrn_operon4=25,rrn_operon5=29,rrn_operon6=121,rrn_operon7=371
integer,parameter :: no_rrn_operon=7



end module parameters


program MC_RING_POLYMER
use parameters
implicit none

real*8::ori1_z_pos(3000000),ori2_z_pos(3000000),ter_z_pos(3000000)
integer::no_partner_rnap_poly(7),partner_rnap_bind_poly(7,npart_rnap),bond_index_rnap(npart_rnap)
real*8 :: xmax,xmin,ymax,ymin,zmax,zmin,d_length
real*8::rep_process,rep,sigma,fc,vc,rc,cyil_length,sigma_nus,rc_nus,vc_nus,rc_nus_free,vc_nus_free
real*8 ::total_en,en_initial,en_final,pot_en,pot_en_nus,pot_en_free_nus
integer::ii,jj,i,k,kk,npart,k_ch,npart_var,iter_crit,npart_var_temp,i_junk
integer:: kbt_eff,niter_index,k_chosen
real*8 ::dx,dx1,dy,dy1,dz,dz1,dr,dr1,kappa_m,delta_m,equil,r
real*8 ::xx1,yy1,zz1,r1,r2,r3,delta_en,pos(3*n_monomer),pos_rnap(3*npart_rnap)
real*8 ::accept,no_partner_poly_rnap(npart_rnap),ll1,pos_nus(3*npart_nus),ll2
real*8:: pos_free_nus(3*npart_free_nus)
real*8::bond_index_nus(npart_nus),no_partner_nus_rnap(npart_rnap),partner_nus_bind_rnap(npart_nus,npart_rnap)
real*8:: v_spring_rnap_poly
character(len=30):: charac_a

call srand(seed)

no_partner_poly_rnap=0.0d0

partner_rnap_bind_poly=0.0d0
partner_nus_bind_rnap=0.0d0
bond_index_nus=0.0d0
bond_index_rnap=0.0d0
no_partner_rnap_poly=0.0d0
no_partner_nus_rnap=0.0d0



!accept=0.0d0



do i=1,100000
r=rand()
enddo!


sigma=0.80d0
sigma_nus=0.10d0

kappa_m=kappa
rc= (2.0d0)**(1.0d0/6.0d0)*sigma
vc = eps*((sigma/rc)**12 - (sigma/rc)**6) 
fc=eps*(12.0d0*(sigma/rc)**13.0d0 - 6.0d0*(sigma/rc)**7.0d0 )



rc_nus=(2.0d0)**(1.0d0/6.0d0)*sigma_nus
!if(jj.gt.niter_eq/2)then
!rc_nus=2.50d0
vc_nus = eps*((sigma_nus/rc_nus)**12 - (sigma_nus/rc_nus)**6)



rc_nus_free=(2.0d0)**(1.0d0/6.0d0)*sigma_nus
vc_nus_free = eps*((sigma_nus/rc_nus_free)**12 - (sigma_nus/rc_nus_free)**6)



cyil_length=17.50d0
!d_length=cyil_length/(n_monomer/2)


ll1=(sigma/2.0d0)+(sigma_rnap/2.0d0)
ll2=(sigma_rnap/2.0d0)+(sigma_nus/2.0d0)
!write(*,*)niter_replicate
xmax=llz/2.0d0 + cyil_rad; xmin=llz/2.0d0 - cyil_rad; 
zmax=llz/2.0d0 + cyil_length/2.0d0; zmin=llz/2.0d0 - cyil_length/2.0d0
!zmax=dsqrt(cyil


!write(*,*)kbt

equil=0.0d0
!n_monomer=1000 ! no. of monomers.
rep_site=0.0d0
npart=n_monomer
!write(*,*)vc
!k_ch=1! Just any arbitary value
total_en =0.0d0;pot_en=0.0d0;pot_en_nus=0.0d0;pot_en_free_nus=0.0d0

npart_var=n_monomer




!!!!!!!!!!!!!!!!!!!!!!!
open(32,file='energy.dat',status='unknown',form='formatted')
open(079,file='pos_init.dat',status='unknown',form='formatted')
open(089,file='pos_final.dat',status='unknown',form='formatted')

open(12,file='demix_para.dat',status='unknown',form='formatted')
open(2,file='rad_gyr.dat',status='unknown',form='formatted')
open(3,file='bond_dist.dat',status='unknown',form='formatted')
open(4,file='lj_energy.dat',status='unknown',form='formatted')
open(5,file='lj_energy_nus.dat',status='unknown',form='formatted')
open(23,file='dist_bond_rand.dat',status='unknown',form='formatted')

open(14,file='dist_bond_nus.dat',status='unknown',form='formatted')




  call initial_energy_calc
  close(079)



!!For first 20 calculations!!!!
call neighbourlist
call neighbourlist_nus
call neighbourlist_free_nus
call neighbourlist_free_bound_nus
! EQUILIBRATION STEP.
!if(eq_over.eq.0) then
    do jj =1,niter_eq ! NITER = no. of Monte Carlo STEPS.
niter_index=jj
!call msd_calc_1     
if(mod(jj,call_neigh).eq.0)then
call neighbourlist
call neighbourlist_nus       
call neighbourlist_free_nus
call neighbourlist_free_bound_nus
endif


if(jj.gt.niter_nus_att_threshold)then
rc_nus_free=2.50d0
vc_nus_free = eps*((sigma_nus/rc_nus_free)**12 - (sigma_nus/rc_nus_free)**6)
endif


do ii=1,(npart+npart_rnap+npart_nus+npart_free_nus)

if(mod(jj,200).eq.0)then
call binding_partner_rnap
call binding_partner_nus 
!write(*,*)'hi'
endif

     call  metropolis_trial_move
enddo
     
!      if(mod(jj,1000).eq.0) write(32,*)jj,(total_en/npart)

if(mod(jj,10000).eq.0)then
call write_config
!call rad_gyration
!call bond_analysis

!if(jj.gt.niter_eq/2)then
!call bond_length_dist
!call lj_energy
!call lj_energy_nus
!endif
!write(*,*)jj
endif

if(mod(jj,1000).eq.0)then
call bond_analysis
write(*,*)jj
endif




enddo
!close(89)

equil=1.0d0


!write(*,*)accept/(npart_var*niter_eq)

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
!write(*,*)npart_var

do i=1,n_monomer
write(089,fmt='(A,3g18.10)') "O",pos(3*i-2),pos(3*i-1),pos(3*i)
enddo

close(89)
close(32)
close(2)
close(3)
close(4)
close(5)
close(23)
close(14)
contains 

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    subroutine  metropolis_trial_move
    implicit none
integer:: rep_a,rep_b,rep_c,j,sp_index,i1,k_ch_rnap,k_ch_nus,k_ch_poly,i2,ki,n1
    real*8 ::dx_rep,dy_rep,r,dz_rep,dr_rep,rr,v_lj      
real*8::ddx,ddy,ddz,dd,temp_x,temp_y,temp_z,pot_en_nus2

!integer,parameter::seed=126482


!call srand(seed)

!sumr=0.0d0
!do i=1,10000
!r=rand()
!enddo!

     




en_initial = 0.0d0; en_final=0.0d0 ! energy of config before/after random step of monomer i  

     i = int(abs(rand())*dfloat(npart_var + npart_rnap + npart_nus + npart_free_nus)) + 1 ! Choose a random monomer from 1 to npart. 
!i=ii

!write(*,*)i



if(i.le.npart)then

!write(*,*)rand()
k_ch=i
k_ch_poly=i

     !!Identifying neighboursi when replication is off!! 
   k=i+1
   kk=i-1

       if(i.eq.npart)then
       k=1
     endif
       if(i.eq.1)then
       kk =npart
     endif

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ! BOND-SPRING ENERGY                
     dx = pos(3*k-2) - pos(3*i-2); dy = pos(3*k-1) - pos(3*i-1); dz = pos(3*k) - pos(3*i)
     dx1 = pos(3*kk-2) - pos(3*i-2); dy1 = pos(3*kk-1) - pos(3*i-1); dz1 = pos(3*kk) - pos(3*i)
     dr = dsqrt(dx*dx + dy*dy + dz*dz); dr1 = dsqrt(dx1*dx1 + dy1*dy1 + dz1*dz1)

     en_initial =0.50d0* (kappa_m*(dr - ll0)**2.0d0 + kappa_m*(dr1 - ll0)**2.0d0) ! ll0 : equilibrium bond length.

     xx1 = pos(3*i-2); yy1 = pos(3*i-1); zz1 = pos(3*i)  ! TRIAL RANDOM STEP.
     call potential ! LJ ENERGY. subroutine potential uses xx1,yy1,zz1
     en_initial=en_initial + (pot_en)

!!Initial energy!!!!!!!!
if((k_ch_poly.eq.rrn_operon1).or.(k_ch_poly.eq.rrn_operon2).or. &
(k_ch_poly.eq.rrn_operon3).or.(k_ch_poly.eq.rrn_operon4).or.  &
(k_ch_poly.eq.rrn_operon5).or.(k_ch_poly.eq.rrn_operon6).or. &
(k_ch_poly.eq.rrn_operon7))then 
if(jj.gt.niter_rnap_threshold)then
!do i1=1,7
if (k_ch_poly.eq.rrn_operon1)then
temp_x=pos(3*rrn_operon1-2)
temp_y=pos(3*rrn_operon1-1)
temp_z=pos(3*rrn_operon1)
i1=1
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if (k_ch_poly.eq.rrn_operon2)then
temp_x=pos(3*rrn_operon2-2)
temp_y=pos(3*rrn_operon2-1)
temp_z=pos(3*rrn_operon2)
i1=2
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if (k_ch_poly.eq.rrn_operon3)then
temp_x=pos(3*rrn_operon3-2)
temp_y=pos(3*rrn_operon3-1)
temp_z=pos(3*rrn_operon3)
i1=3
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if (k_ch_poly.eq.rrn_operon4)then
temp_x=pos(3*rrn_operon4-2)
temp_y=pos(3*rrn_operon4-1)
temp_z=pos(3*rrn_operon4)
i1=4
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if (k_ch_poly.eq.rrn_operon5)then
temp_x=pos(3*rrn_operon5-2)
temp_y=pos(3*rrn_operon5-1)
temp_z=pos(3*rrn_operon5)
i1=5
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if (k_ch_poly.eq.rrn_operon6)then
temp_x=pos(3*rrn_operon6-2)
temp_y=pos(3*rrn_operon6-1)
temp_z=pos(3*rrn_operon6)
i1=6
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if (k_ch_poly.eq.rrn_operon7)then
temp_x=pos(3*rrn_operon7-2)
temp_y=pos(3*rrn_operon7-1)
temp_z=pos(3*rrn_operon7)
i1=7
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
!enddo



endif
endif
!!!!!Trial move!!!!!!!!!!!!
     r1=2*(rand()-0.50d0); r2 =2*(rand()-0.50d0); r3= 2*(rand()-0.50d0)  ! THREE RANDOM NUMBERS.
     xx1 = pos(3*i-2) + delta*r1; yy1 = pos(3*i-1) + delta*r2; zz1 = pos(3*i) + delta*r3 ! TRIAL RANDOM STEP.

! Calculate change in energy due to change in position.
    
    ! BOND-SPRING ENERGY                
    dx  = pos(3*k-2)  - xx1;  dy  = pos(3*k-1) - yy1; dz  = pos(3*k)  - zz1
    dx1 = pos(3*kk-2) - xx1; dy1 = pos(3*kk-1) - yy1; dz1 = pos(3*kk) - zz1

    dr = dsqrt(dx*dx + dy*dy + dz*dz); dr1 = dsqrt(dx1*dx1 + dy1*dy1 + dz1*dz1)
    en_final =0.50d0*(kappa_m*(dr - ll0)**2.0d0 + kappa_m*(dr1 - ll0)**2.0d0) ! ll0 : equilibrium bond length.

 call potential ! LJ ENERGY

   en_final =en_final + pot_en


if((k_ch_poly.eq.rrn_operon1).or.(k_ch_poly.eq.rrn_operon2).or. &
(k_ch_poly.eq.rrn_operon3).or.(k_ch_poly.eq.rrn_operon4).or.  &
(k_ch_poly.eq.rrn_operon5).or.(k_ch_poly.eq.rrn_operon6).or. &
(k_ch_poly.eq.rrn_operon7))then
if(jj.gt.niter_rnap_threshold)then
!do i1=1,7
if((k_ch_poly.eq.rrn_operon1))then
temp_x=xx1
temp_y=yy1
temp_z=zz1
i1=1
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
!write(*,*)'hi'
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if((k_ch_poly.eq.rrn_operon2))then
temp_x=xx1
temp_y=yy1
temp_z=zz1
i1=2
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
!write(*,*)'hi'
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if((k_ch_poly.eq.rrn_operon3))then
temp_x=xx1
temp_y=yy1
temp_z=zz1
i1=3
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
!write(*,*)'hi'
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if((k_ch_poly.eq.rrn_operon4))then
temp_x=xx1
temp_y=yy1
temp_z=zz1
i1=4
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
!write(*,*)'hi'
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if((k_ch_poly.eq.rrn_operon5))then
temp_x=xx1
temp_y=yy1
temp_z=zz1
i1=5
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
!write(*,*)'hi'
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if((k_ch_poly.eq.rrn_operon6))then
temp_x=xx1
temp_y=yy1
temp_z=zz1
i1=6
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
!write(*,*)'hi'
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
if((k_ch_poly.eq.rrn_operon7))then
temp_x=xx1
temp_y=yy1
temp_z=zz1
i1=7
do j=1, npart_rnap
if(bond_index_rnap(j).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,j).eq.1.0d0)then
!write(*,*)'hi'
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
!endif

endif
endif
!endif

    delta_en = en_final - en_initial

!write(*,*)jj,en_initial,en_final,delta_en
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
elseif ((i.gt.npart).and.(i.le.(npart+npart_rnap)))then!!!!!!!!!rnap particles chosen
       
   r1=2*(rand()-0.50d0); r2 =2*(rand()-0.50d0); r3= 2*(rand()-0.50d0)  ! THREE RANDOM NUMBERS.
xx1 = pos_rnap(3*(i-npart_var)-2)+delta*r1; yy1 = pos_rnap(3*(i-npart_var)-1)+delta*r2;zz1 =pos_rnap(3*(i-npart_var))+delta*r3 ! TRIAL RANDOM STEP.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!write(*,*)i,xx1,yy1,zz1
k_ch_rnap=i-npart

!!!Initial energy!!!!!!!!
if(bond_index_rnap(k_ch_rnap).eq.1.0d0)then
if(jj.gt.niter_rnap_threshold)then
!if(bond_index_rnap(k_ch_rnap).eq.1.0d0)then

do i1=1,7
if (i1.eq.1)then
temp_x=pos(3*rrn_operon1-2)
temp_y=pos(3*rrn_operon1-1)
temp_z=pos(3*rrn_operon1)
endif
if (i1.eq.2)then
temp_x=pos(3*rrn_operon2-2)
temp_y=pos(3*rrn_operon2-1)
temp_z=pos(3*rrn_operon2)
endif
if (i1.eq.3)then
temp_x=pos(3*rrn_operon3-2)
temp_y=pos(3*rrn_operon3-1)
temp_z=pos(3*rrn_operon3)
endif
if (i1.eq.4)then
temp_x=pos(3*rrn_operon4-2)
temp_y=pos(3*rrn_operon4-1)
temp_z=pos(3*rrn_operon4)
endif
if (i1.eq.5)then
temp_x=pos(3*rrn_operon5-2)
temp_y=pos(3*rrn_operon5-1)
temp_z=pos(3*rrn_operon5)
endif
if (i1.eq.6)then
temp_x=pos(3*rrn_operon6-2)
temp_y=pos(3*rrn_operon6-1)
temp_z=pos(3*rrn_operon6)
endif
if (i1.eq.7)then
temp_x=pos(3*rrn_operon7-2)
temp_y=pos(3*rrn_operon7-1)
temp_z=pos(3*rrn_operon7)
endif

if(bond_index_rnap(k_ch_rnap).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,k_ch_rnap).eq.1.0d0)then
ddx= -pos_rnap(3*k_ch_rnap-2) + temp_x
ddy= -pos_rnap(3*k_ch_rnap-1) + temp_y
ddz= -pos_rnap(3*k_ch_rnap) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo


!endif
endif

if(jj.gt.niter_nus_threshold)then
do i1=1,npart_nus
if (bond_index_nus(i1).eq.1.0d0)then
if(partner_nus_bind_rnap(i1,k_ch_rnap).eq.1.0d0)then
ddx= -pos_rnap(3*k_ch_rnap-2) + pos_nus(3*i1-2)
ddy= -pos_rnap(3*k_ch_rnap-1) + pos_nus(3*i1-1)
ddz= -pos_rnap(3*k_ch_rnap) + pos_nus(3*i1)
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50*kappa_nus*(dd-ll2)**2.0d0
endif
endif
enddo
endif
endif

!!!!!!!!!!Final energy!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

if(bond_index_rnap(k_ch_rnap).eq.1.0d0)then

if(jj.gt.niter_rnap_threshold)then

do i1=1,7
if (i1.eq.1)then
temp_x=pos(3*rrn_operon1-2)
temp_y=pos(3*rrn_operon1-1)
temp_z=pos(3*rrn_operon1)
endif
if (i1.eq.2)then
temp_x=pos(3*rrn_operon2-2)
temp_y=pos(3*rrn_operon2-1)
temp_z=pos(3*rrn_operon2)
endif
if (i1.eq.3)then
temp_x=pos(3*rrn_operon3-2)
temp_y=pos(3*rrn_operon3-1)
temp_z=pos(3*rrn_operon3)
endif
if (i1.eq.4)then
temp_x=pos(3*rrn_operon4-2)
temp_y=pos(3*rrn_operon4-1)
temp_z=pos(3*rrn_operon4)
endif
if (i1.eq.5)then
temp_x=pos(3*rrn_operon5-2)
temp_y=pos(3*rrn_operon5-1)
temp_z=pos(3*rrn_operon5)
endif
if (i1.eq.6)then
temp_x=pos(3*rrn_operon6-2)
temp_y=pos(3*rrn_operon6-1)
temp_z=pos(3*rrn_operon6)
endif
if (i1.eq.7)then
temp_x=pos(3*rrn_operon7-2)
temp_y=pos(3*rrn_operon7-1)
temp_z=pos(3*rrn_operon7)
endif

if(bond_index_rnap(k_ch_rnap).eq.1.0d0)then
if(partner_rnap_bind_poly(i1,k_ch_rnap).eq.1.0d0)then
ddx= -xx1 + temp_x
ddy= -yy1 + temp_y
ddz= -zz1 + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50d0*kappa_operon*(dd-ll1)**2.0d0
endif
endif
enddo
endif
!endif

if(jj.gt.niter_nus_threshold)then
do i1=1,npart_nus
if (bond_index_nus(i1).eq.1.0d0)then
if(partner_nus_bind_rnap(i1,k_ch_rnap).eq.1.0d0)then
ddx= -xx1 + pos_nus(3*i1-2)
ddy= -yy1 + pos_nus(3*i1-1)
ddz= -zz1 + pos_nus(3*i1)
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50*kappa_nus*(dd-ll2)**2.0d0
endif
endif
enddo
endif
endif
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        delta_en=en_final-en_initial 

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

else !!!!!!!! nus particles chosen

k_ch=i-npart_var-npart_rnap
k_ch_nus=i-npart-npart_rnap


if(k_ch_nus.le.npart_nus)then
xx1 = pos_nus(3*(i-npart_var-npart_rnap)-2); yy1 =pos_nus(3*(i-npart_var-npart_rnap)-1)
zz1 = pos_nus(3*(i-npart_var-npart_rnap)) ! TRIAL RANDOM STEP.
else
xx1 = pos_free_nus(3*(i-npart_var-npart_rnap-npart_nus)-2); 
yy1=pos_free_nus(3*(i-npart_var-npart_rnap-npart_nus)-1)
zz1 = pos_free_nus(3*(i-npart_var-npart_rnap-npart_nus)) ! TRIAL RANDOM STEP.
endif


if(k_ch_nus.le.npart_nus)then

k_ch=i-npart_var-npart_rnap
call potential_nus

pot_en_nus2=0.0d0
i2=k_ch_nus
!write(*,*)i,i2
do ki=1,no_neighbour_free_bound_nus(i2)
n1=neigh_list_free_bound_nus(i2,ki)
ddx=pos_nus(3*i2-2)-pos_free_nus(3*n1-2)
ddy=pos_nus(3*i2-1)-pos_free_nus(3*n1-1)
ddz=pos_nus(3*i2)-pos_free_nus(3*n1)
dd= dsqrt(ddx**2.0d0 + ddy**2.0d0 + ddz**2.0d0)
if(dd.le.rc_nus_free) then ! local attraction between beads in a segment.
v_lj=eps*((sigma_nus/dd)**12.0d0 - (sigma_nus/dd)**6.0d0 )  - vc_nus_free
pot_en_nus2=pot_en_nus2 + v_lj
endif !  if(dd.le.sigmac1) then 
!enddo
enddo


en_initial=en_initial + (pot_en_nus + pot_en_nus2  )

if (bond_index_nus(k_ch_nus).eq.1.0d0)then
if(jj.gt.niter_nus_threshold)then
do j=1, npart_rnap
if (bond_index_nus(k_ch_nus).eq.1.0d0)then
if(partner_nus_bind_rnap(k_ch_nus,j).eq.1.0d0)then
ddx= -pos_rnap(3*j-2) + pos_nus(3*k_ch_nus-2)
ddy= -pos_rnap(3*j-1) + pos_nus(3*k_ch_nus-1)
ddz= -pos_rnap(3*j) + pos_nus(3*k_ch_nus)
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_initial=en_initial + 0.50*kappa_nus*(dd-ll2)**2.0d0
endif
endif
enddo
endif
endif
!!!!!!!!!!!!
else
!!!!!!!!!!!!!!!!
!write(*,*)i,'hi'
k_ch=i-npart-npart_rnap-npart_nus

call potential_free_nus

en_initial=en_initial+pot_en_free_nus

pot_en_nus2=0.0d0
i2=k_ch
!write(*,*)i,i2
do ki=1,no_neighbour_free_bound_nus(k_ch)
n1=neigh_list_free_bound_nus(i2,ki)
ddx=pos_nus(3*n1-2)-pos_free_nus(3*i2-2)
ddy=pos_nus(3*n1-1)-pos_free_nus(3*i2-1)
ddz=pos_nus(3*n1)-pos_free_nus(3*i2)
dd= dsqrt(ddx**2.0d0 + ddy**2.0d0 + ddz**2.0d0)
if(dd.le.rc_nus_free) then ! local attraction between beads in a segment.
v_lj=eps*((sigma_nus/dd)**12.0d0 - (sigma_nus/dd)**6.0d0 )  - vc_nus_free
pot_en_nus2=pot_en_nus2 + v_lj
endif !  if(dd.le.sigmac1) then 
!enddo
enddo


en_initial=en_initial+ pot_en_nus2

endif

!####### Trial move ##########1
r1=2*(rand()-0.50d0); r2 =2*(rand()-0.50d0); r3= 2*(rand()-0.50d0)  ! THREE RANDOM NUMBERS.

if(k_ch_nus.le.npart_nus)then
xx1 = pos_nus(3*(i-npart_var-npart_rnap)-2) + delta*r1; yy1 = pos_nus(3*(i-npart_var-npart_rnap)-1) + delta*r2 
zz1 = pos_nus(3*(i-npart_var-npart_rnap)) + delta*r3 ! TRIAL RANDOM STEP.
else
xx1 = pos_free_nus(3*(i-npart_var-npart_rnap-npart_nus)-2) + delta*r1 ;
yy1=pos_free_nus(3*(i-npart_var-npart_rnap-npart_nus)-1) + delta*r2;
zz1 = pos_free_nus(3*(i-npart_var-npart_rnap-npart_nus)) + delta*r3; ! TRIAL RANDOM STEP.
endif

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
if(k_ch_nus.le.npart_nus)then

k_ch=i-npart_var-npart_rnap
call potential_nus

en_final=en_final + (pot_en_nus)

if (bond_index_nus(k_ch_nus).eq.1.0d0)then
if(jj.gt.niter_nus_threshold)then
do j=1, npart_rnap
if (bond_index_nus(k_ch_nus).eq.1.0d0)then
if(partner_nus_bind_rnap(k_ch_nus,j).eq.1.0d0)then
ddx=-pos_rnap(3*j-2) + xx1
ddy= -pos_rnap(3*j-1) + yy1
ddz= -pos_rnap(3*j) + zz1
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
en_final=en_final + 0.50*kappa_nus*(dd-ll2)**2.0d0
endif
endif
enddo
endif
endif


pot_en_nus2=0.0d0
i2=k_ch_nus
!write(*,*)i,i2
do ki=1,no_neighbour_free_bound_nus(i2)
n1=neigh_list_free_bound_nus(i2,ki)
ddx=xx1-pos_free_nus(3*n1-2)
ddy=yy1-pos_free_nus(3*n1-1)
ddz=zz1-pos_free_nus(3*n1)
dd= dsqrt(ddx**2.0d0 + ddy**2.0d0 + ddz**2.0d0)
if(dd.le.rc_nus_free) then ! local attraction between beads in a segment.
v_lj=eps*((sigma_nus/dd)**12.0d0 - (sigma_nus/dd)**6.0d0 )  - vc_nus_free
pot_en_nus2=pot_en_nus2 + v_lj
endif !  if(dd.le.sigmac1) then 
!enddo
enddo






en_final=en_final + (pot_en_nus2)


!delta_en=en_final-en_initial !!! To be changed soon!!!!!!!

else

k_ch=i-npart-npart_rnap-npart_nus

call potential_free_nus

en_final=en_final + (pot_en_free_nus)


pot_en_nus2=0.0d0
i2=k_ch
!write(*,*)i,i2
do ki=1,no_neighbour_free_bound_nus(k_ch)
n1=neigh_list_free_bound_nus(i2,ki)
ddx=pos_nus(3*n1-2)-xx1
ddy=pos_nus(3*n1-1)-yy1
ddz=pos_nus(3*n1)-zz1
dd= dsqrt(ddx**2.0d0 + ddy**2.0d0 + ddz**2.0d0)
if(dd.le.rc_nus_free) then ! local attraction between beads in a segment.
v_lj=eps*((sigma_nus/dd)**12.0d0 - (sigma_nus/dd)**6.0d0 )  - vc_nus_free
pot_en_nus2=pot_en_nus2 + v_lj
endif !  if(dd.le.sigmac1) then 
!enddo
enddo



en_final=en_final + (pot_en_nus2)

!write(*,*)i,en_final,en_initial

    endif

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
delta_en=en_final-en_initial !!! !!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


endif



    if (delta_en.le.0.0d0) then  ! METROPOLIS ALGO ! NOTE LESS THAN OR EQUAL TO
       if(xx1.lt.llz)then
         if(xx1.gt.(-llz))then
   if(yy1.lt.llz)then
         if(yy1.gt.(-llz))then
 if(zz1.lt.llz)then
         if(zz1.gt.(-llz))then
if(confine.eq.1.0d0)then
ymax=0.0d0;ymin=0.0d0
 if(xx1<xmax.and.xx1>xmin) then
         ymax=llz/2.0d0 + dsqrt(cyil_rad**2-(xx1-llz/2.0d0)**2);
ymin=llz/2.0d0-dsqrt(cyil_rad**2-(xx1-llz/2.0d0)**2)
      endif
 if(xx1<xmax.and.xx1>xmin.and.yy1<ymax.and.yy1>ymin.and.zz1<zmax.and.zz1>zmin) then

!write(*,*)i
         if (i.le.npart_var)then
         pos(3*i-2) = xx1; pos(3*i-1) = yy1;  pos(3*i) = zz1
         elseif((i.gt.npart_var).and.(i.le.(npart_var + npart_rnap)))then
         pos_rnap(3*(i-npart_var)-2) = xx1; pos_rnap(3*(i-npart_var)-1) = yy1;  pos_rnap(3*(i-npart_var)) = zz1
!write(*,*)i,xx1,yy1,zz1
         elseif((i.gt.npart+npart_rnap).and.(i.le.(npart+npart_rnap+npart_nus)))then
pos_nus(3*(i-npart_var-npart_rnap)-2) = xx1; pos_nus(3*(i-npart_var-npart_rnap)-1) = yy1; pos_nus(3*(i-npart_var-npart_rnap)) = zz1
else
pos_free_nus(3*(i-npart-npart_rnap-npart_nus)-2) = xx1;
pos_free_nus(3*(i-npart-npart_rnap-npart_nus)-1) = yy1; 
pos_free_nus(3*(i-npart-npart_rnap-npart_nus))= zz1
endif  



!accept=accept +1.0d0
 total_en = total_en + delta_en

   endif
   endif         
endif
       endif
     endif
   endif
 endif
 endif 
         else 
       rr= rand()
       if(rr.lt.exp(-delta_en/kbt)) then
      if(xx1.lt.llz)then
         if(xx1.gt.(-llz))then
   if(yy1.lt.llz)then
         if(yy1.gt.(-llz))then
 if(zz1.lt.llz)then
         if(zz1.gt.(-llz))then
if(confine.eq.1.0)then

ymax=0.0d0;ymin=0.0d0
 if(xx1<xmax.and.xx1>xmin) then
 ymax=llz/2.0d0 + dsqrt(cyil_rad**2-(xx1-llz/2.0d0)**2)  
 ymin=llz/2.0d0 - dsqrt(cyil_rad**2-(xx1-llz/2.0d0)**2)
    endif

 if(xx1<xmax.and.xx1>xmin.and.yy1<ymax.and.yy1>ymin.and.zz1<zmax.and.zz1>zmin) then
    
        if (i.le.npart_var)then
         pos(3*i-2) = xx1; pos(3*i-1) = yy1;  pos(3*i) = zz1
         elseif((i.gt.npart_var).and.(i.le.(npart_var + npart_rnap)))then
         pos_rnap(3*(i-npart_var)-2) = xx1; pos_rnap(3*(i-npart_var)-1) = yy1;
pos_rnap(3*(i-npart_var)) = zz1
   elseif((i.gt.npart+npart_rnap).and.(i.le.(npart+npart_rnap+npart_nus)))then
         pos_nus(3*(i-npart_var-npart_rnap)-2) = xx1;
pos_nus(3*(i-npart_var-npart_rnap)-1) = yy1; pos_nus(3*(i-npart_var-npart_rnap))= zz1
else
pos_free_nus(3*(i-npart-npart_rnap-npart_nus)-2) = xx1;
pos_free_nus(3*(i-npart-npart_rnap-npart_nus)-1) = yy1;
pos_free_nus(3*(i-npart-npart_rnap-npart_nus))= zz1
endif
 
         total_en = total_en + delta_en
  
! accept=accept+1.0d0
   
   
   endif
   endif 
        endif
       endif
     endif
   endif
 endif
 endif

     
         endif
    endif   

    end subroutine  metropolis_trial_move


!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subroutine initial_energy_calc
implicit none
real*8:: pi,length_polymer,radius,d_theta,theta
integer:: ij,pp,n,kp
real*8 :: ddx,ddy,ddz,dd,v1_lj
!pi = 2.0d0*asin(1.0d0)
length_polymer = dfloat(n_monomer)*ll0 ! length of polymer.
radius= length_polymer/(30.0d0*pi) ! of ring polymer.

! INITIALIZE POSITION OF MONOMERS OF RING POLYMERS.


do i=1,npart_var

pos(3*i-2)=llz/2.0d0 + (rand()-0.50d0)*(cyil_rad-1.0d0)
pos(3*i)=llz/2.0d0 + (rand()-0.50d0)*(cyil_length-1.0d0)
pos(3*i-1)=llz/2.0d0

enddo

   do i=1,npart_rnap
pos_rnap(3*i-2)=llz/2.0d0 + (rand()-0.50d0)*(cyil_rad-1.0d0)
pos_rnap(3*i)=llz/2.0d0 + (rand()-0.50d0)*(cyil_length-1.0d0)
pos_rnap(3*i-1)=llz/2.0d0 
enddo



do i=1,npart_nus
pos_nus(3*i-2)=llz/2.0d0 + (rand()-0.50d0)*(cyil_rad-1.0d0)
pos_nus(3*i)=llz/2.0d0 + (rand()-0.50d0)*(cyil_length-1.0d0)
pos_nus(3*i-1)=llz/2.0d0
enddo



do i=1,npart_free_nus
pos_free_nus(3*i-2)=llz/2.0d0 + (rand()-0.50d0)*(cyil_rad-1.0d0)
pos_free_nus(3*i)=llz/2.0d0 + (rand()-0.50d0)*(cyil_length-1.0d0)
pos_free_nus(3*i-1)=llz/2.0d0
enddo









total_en=0.0d0
do i = 1,npart  ! 1 MC step
   
    k = i+ 1
kk=i-1    
if(i.eq.npart)then 
k=1  
kk=i-1       ! SINCE IT is a RING POLYMER.
endif

if(i.eq.1)then
kk=npart
k=i+1
endif
   
 dx = pos(3*k-2) - pos(3*i-2); dy = pos(3*k-1) - pos(3*i-1); dz = pos(3*k) - pos(3*i)
    dr = dsqrt(dx*dx + dy*dy + dz*dz)
    total_en  = total_en + 0.50d0*kappa*(dr - ll0)**2 ! ll0 : equilibrium bond length.

dx = pos(3*kk-2) - pos(3*i-2); dy = pos(3*kk-1) - pos(3*i-1) 
dz = pos(3*kk) -pos(3*i)
    dr = dsqrt(dx*dx + dy*dy + dz*dz)
    total_en  = total_en + 0.50d0*kappa*(dr - ll0)**2 ! ll0 : equilibrium bond
!length.


enddo

do ij=1, npart-1
  do pp= ij+1,npart

   ddx=pos(3*ij-2) - pos(3*pp-2);! if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
   ddy=pos(3*ij-1) - pos(3*pp-1);! if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
   ddz=pos(3*ij) - pos(3*pp);! if(abs(ddz).gt.llxby2) ddz=-abs(llx-ddz)*ddz/abs(ddz)
   dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)

    if(dd.le.rc) then ! local attraction between beads in a segment.

     v1_lj= eps*((sigma/dd)**12.0d0 - (sigma/dd)**6.0d0 )  - vc
     total_en=total_en+v1_lj
!write(*,*)v_lj,dd
    endif !  if(dd.le.sigmac1) then 
  enddo
enddo




end subroutine  initial_energy_calc


!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subroutine potential
implicit none
integer:: ij,pp,n
real*8 :: ddx,ddy,ddz,dd,v_lj

pot_en=0.0d0;v_lj=0.0d0

  do pp= 1,no_neighbour(k_ch)
    n=neigh_list(k_ch,pp)
    ddx=xx1 - pos(3*n-2);! if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
    ddy=yy1 - pos(3*n-1);! if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
    ddz=zz1 - pos(3*n);! if(abs(ddz).gt.llxby2) ddz=-abs(llx-ddz)*ddz/abs(ddz)

    dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
    if(dd.le.rc) then ! local attraction between beads in a segment.
     v_lj= eps*((sigma/dd)**12.0d0 - (sigma/dd)**6.0d0 )  - vc 
     pot_en=pot_en+v_lj
    endif !  if(dd.le.sigmac1) then 

  enddo

!write(*,*)jj,rc,vc

end subroutine potential
!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subroutine potential_nus

implicit none
integer:: ij,pp,n
real*8 :: ddx,ddy,ddz,dd,v_lj

pot_en_nus=0.0d0;v_lj=0.0d0

  do pp= 1,no_neighbour_nus(k_ch)
    n=neigh_list_nus(k_ch,pp)
    ddx=xx1 - pos_nus(3*n-2);! if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
    ddy=yy1 - pos_nus(3*n-1);! if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
    ddz=zz1 - pos_nus(3*n);! if(abs(ddz).gt.llxby2) ddz=-abs(llx-ddz)*ddz/abs(ddz)

    dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
    if(dd.le.rc_nus) then ! local attraction between beads in a segment.
     v_lj=eps*((sigma_nus/dd)**12.0d0 - (sigma_nus/dd)**6.0d0 )  - vc_nus
     pot_en_nus=pot_en_nus+v_lj
    endif !  if(dd.le.sigmac1) then 

  enddo

end subroutine potential_nus


!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subroutine potential_free_nus

implicit none
integer:: ij,pp,n
real*8 :: ddx,ddy,ddz,dd,v_lj

pot_en_free_nus=0.0d0;v_lj=0.0d0

  do pp= 1,no_neighbour_free_nus(k_ch)
    n=neigh_list_free_nus(k_ch,pp)
    ddx=xx1 - pos_free_nus(3*n-2);! if(abs(ddx).gt.llxby2)
!ddx=-abs(llx-ddx)*ddx/abs(ddx)
    ddy=yy1 - pos_free_nus(3*n-1);! if(abs(ddy).gt.llxby2)
!ddy=-abs(llx-ddy)*ddy/abs(ddy)
    ddz=zz1 - pos_free_nus(3*n);! if(abs(ddz).gt.llxby2)
!ddz=-abs(llx-ddz)*ddz/abs(ddz)

    dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
    if(dd.le.rc_nus_free) then ! local attraction between beads in a segment.
     v_lj=eps*((sigma_nus/dd)**12.0d0 - (sigma_nus/dd)**6.0d0 )  - vc_nus_free
     pot_en_free_nus=pot_en_free_nus+v_lj
    endif !  if(dd.le.sigmac1) then 

  enddo

end subroutine potential_free_nus

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






!!!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subroutine neighbourlist
implicit none
integer:: ij,pp
real*8 :: ddx,ddy,ddz,dd

no_neighbour=0.0d0;neigh_list=0.0d0
do ij=1, (npart_var)-1
  do pp= ij+1,npart_var

  ddx=pos(3*ij-2) - pos(3*pp-2); !if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
  ddy=pos(3*ij-1) - pos(3*pp-1); !if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
  ddz=pos(3*ij) - pos(3*pp); !if(abs(ddz).gt.llxby2) ddz=-abs(llx-ddz)*ddz/abs(ddz)

  dd=dsqrt(ddx*ddx+ddy*ddy+ddz*ddz)
!write(*,*)dd,pp
  if(dd.lt.rskin)then
  no_neighbour(ij)= no_neighbour(ij) +1 ! BTW for reasons of speed, ij should be the  right index, no_neighbour on left
  neigh_list(ij,no_neighbour(ij))=pp
  no_neighbour(pp)= no_neighbour(pp) +1
  neigh_list(pp,no_neighbour(pp))=ij

!

!write(*,*)no_neighbour(ij)
endif
  enddo
  enddo
  endsubroutine neighbourlist
!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subroutine neighbourlist_nus
implicit none
integer:: ij,pp
real*8 :: ddx,ddy,ddz,dd

no_neighbour_nus=0.0d0;neigh_list_nus=0.0d0
do ij=1, (npart_nus)-1
  do pp= ij+1,npart_nus

  ddx=pos_nus(3*ij-2) - pos_nus(3*pp-2); !if(abs(ddx).gt.llxby2)
!ddx=-abs(llx-ddx)*ddx/abs(ddx)
  ddy=pos_nus(3*ij-1) - pos_nus(3*pp-1); !if(abs(ddy).gt.llxby2)
!ddy=-abs(llx-ddy)*ddy/abs(ddy)
  ddz=pos_nus(3*ij) - pos_nus(3*pp); !if(abs(ddz).gt.llxby2)
!ddz=-abs(llx-ddz)*ddz/abs(ddz)

  dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
!write(*,*)dd,pp
  if(dd.lt.rskin)then
  no_neighbour_nus(ij)= no_neighbour_nus(ij) +1 ! BTW for reasons of speed, ij should be the  right index, no_neighbour on left
  neigh_list_nus(ij,no_neighbour_nus(ij))=pp
  no_neighbour_nus(pp)= no_neighbour_nus(pp) +1
  neigh_list_nus(pp,no_neighbour_nus(pp))=ij
!write(*,*)no_neighbour(ij)
endif
  enddo
  enddo

endsubroutine neighbourlist_nus
!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subroutine neighbourlist_free_nus
implicit none
integer:: ij,pp
real*8 :: ddx,ddy,ddz,dd

no_neighbour_free_nus=0.0d0;neigh_list_free_nus=0.0d0
do ij=1, (npart_free_nus)-1
  do pp= ij+1,npart_free_nus

  ddx=pos_free_nus(3*ij-2) - pos_free_nus(3*pp-2); !if(abs(ddx).gt.llxby2)
!ddx=-abs(llx-ddx)*ddx/abs(ddx)
  ddy=pos_free_nus(3*ij-1) - pos_free_nus(3*pp-1); !if(abs(ddy).gt.llxby2)
!ddy=-abs(llx-ddy)*ddy/abs(ddy)
  ddz=pos_free_nus(3*ij) - pos_free_nus(3*pp); !if(abs(ddz).gt.llxby2)
!ddz=-abs(llx-ddz)*ddz/abs(ddz)

  dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
!write(*,*)dd,pp
  if(dd.lt.rskin)then
  no_neighbour_free_nus(ij)= no_neighbour_free_nus(ij) +1 ! BTW for reasons of speed, ij should be the  right index, no_neighbour on left
  neigh_list_free_nus(ij,no_neighbour_free_nus(ij))=pp
  no_neighbour_free_nus(pp)= no_neighbour_free_nus(pp) +1
  neigh_list_free_nus(pp,no_neighbour_free_nus(pp))=ij
!write(*,*)no_neighbour(ij)
endif
  enddo
  enddo

endsubroutine neighbourlist_free_nus
!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subroutine neighbourlist_free_bound_nus
implicit none
integer:: ij,pp
real*8 :: ddx,ddy,ddz,dd

no_neighbour_free_bound_nus=0.0d0;neigh_list_free_bound_nus=0.0d0
do ij=1, (npart_free_nus)-1
  do pp= ij+1,npart_nus

  ddx=pos_free_nus(3*ij-2) - pos_nus(3*pp-2); !if(abs(ddx).gt.llxby2)
!ddx=-abs(llx-ddx)*ddx/abs(ddx)
  ddy=pos_free_nus(3*ij-1) - pos_nus(3*pp-1); !if(abs(ddy).gt.llxby2)
!ddy=-abs(llx-ddy)*ddy/abs(ddy)
  ddz=pos_free_nus(3*ij) - pos_nus(3*pp); !if(abs(ddz).gt.llxby2)
!ddz=-abs(llx-ddz)*ddz/abs(ddz)

  dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
!write(*,*)dd,pp
  if(dd.lt.rskin)then
  no_neighbour_free_bound_nus(ij)= no_neighbour_free_bound_nus(ij) +1 ! BTW for reasons of speed, ij should be the  right index, no_neighbour on left
  neigh_list_free_bound_nus(ij,no_neighbour_free_bound_nus(ij))=pp
  no_neighbour_free_bound_nus(pp)= no_neighbour_free_bound_nus(pp) +1
  neigh_list_free_bound_nus(pp,no_neighbour_free_bound_nus(pp))=ij
!write(*,*)no_neighbour(ij)
endif
  enddo
  enddo

endsubroutine neighbourlist_free_bound_nus








!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subroutine write_config
implicit none
integer::i,ij
character(len=30) :: charac_a

charac_a ='store_'

       call addnumtostring(charac_a,jj)
       open(083,file=charac_a,status='unknown',form='formatted')
do i=1,npart

  if(i.eq.rrn_operon1)then
   write(083,fmt='(A,3g18.10)')"H",pos(3*i-2),pos(3*i-1),pos(3*i)
  endif

if(i.eq.rrn_operon2)then
   write(083,fmt='(A,3g18.10)')"H",pos(3*i-2),pos(3*i-1),pos(3*i)
      endif

if(i.eq.rrn_operon3)then
   write(083,fmt='(A,3g18.10)')"H",pos(3*i-2),pos(3*i-1),pos(3*i)
endif

if(i.eq.rrn_operon4)then
write(083,fmt='(A,3g18.10)')"H",pos(3*i-2),pos(3*i-1),pos(3*i)
endif

if(i.eq.rrn_operon5)then
write(083,fmt='(A,3g18.10)')"H",pos(3*i-2),pos(3*i-1),pos(3*i)
endif

if(i.eq.rrn_operon6)then
write(083,fmt='(A,3g18.10)')"H",pos(3*i-2),pos(3*i-1),pos(3*i)
endif

if(i.eq.rrn_operon7)then
write(083,fmt='(A,3g18.10)')"H",pos(3*i-2),pos(3*i-1),pos(3*i)
endif







write(083,fmt='(A,3g18.10)') "O",pos(3*i-2),pos(3*i-1),pos(3*i)

enddo


do i=1,npart_rnap
write(083,fmt='(A,3g18.10)') "C",pos_rnap(3*i-2),pos_rnap(3*i-1),pos_rnap(3*i)
enddo

do i=1,npart_nus

if(bond_index_nus(i).eq.0.0d0)then
write(083,fmt='(A,3g18.10)') "F",pos_nus(3*i-2),pos_nus(3*i-1),pos_nus(3*i)
else
write(083,fmt='(A,3g18.10)') "N",pos_nus(3*i-2),pos_nus(3*i-1),pos_nus(3*i)
endif

enddo


do i=1,npart_free_nus
write(083,fmt='(A,3g18.10)') "Na",pos_free_nus(3*i-2),pos_free_nus(3*i-1),pos_free_nus(3*i)
enddo




close(083)
endsubroutine write_config

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subroutine rad_gyration
real*8::tempx,tempy,tempz
real*8:: sum_temp
integer::i,j,k
tempx=0.0d0;tempy=0.0d0;tempz=0.0d0
sum_temp=0.0d0

do i=1,npart_var
tempx=tempx + pos(3*i-2)
tempy=tempy + pos(3*i-1)
tempz=tempz + pos(3*i)
enddo
tempx=tempx/npart_var
tempy=tempy/npart_var
tempz=tempz/npart_var

do i=1,npart_var
sum_temp=sum_temp + (tempx-pos(3*i-2))**2.0d0 + (tempy-pos(3*i-1))**2.0d0 +(tempz-pos(3*i))**2.0d0
enddo
sum_temp=sum_temp/npart_var

write(2,*)jj,dsqrt(sum_temp)

endsubroutine rad_gyration

subroutine bond_length_dist
implicit none
integer::i,j,k
real*8 :: dx,dy,dz,dd
real*8:: k_count,av_bond_dist

av_bond_dist=0.0d0;k_count=0.0d0

do i=2,npart_var-3
!do j=i+1,npart_var-2
j=i+1

dx= pos(3*j-2)-pos(3*i-2)
dy=pos(3*j-1)-pos(3*i-1)
dz=pos(3*j) - pos(3*i)

dd=sqrt(dx*dx + dy*dy + dz*dz)


k_count=k_count+1.0d0
av_bond_dist=av_bond_dist + 0.50d0*kappa*(dd-ll0)**2.0d0
!av_bond_dist=av_bond_dist + dd

!enddo
enddo



av_bond_dist=av_bond_dist/k_count

write(3,*)jj,av_bond_dist

endsubroutine bond_length_dist


subroutine lj_energy
implicit none
integer::i,j,k
real*8::pot_en2,v2_lj,kcount2
real*8:: ddx,ddy,ddz,dd

pot_en2=0.0d0;v2_lj=0.0d0
do i= 1,npart-1
do j=i+1,npart   
 
    ddx=pos(3*i-2) - pos(3*j-2);! if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
    ddy=pos(3*i-1) - pos(3*j-1);! if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
    ddz=pos(3*i) - pos(3*j);! if(abs(ddz).gt.llxby2) ddz=-abs(llx-ddz)*ddz/abs(ddz)

    dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
    if(dd.le.rc) then ! local attraction between beads in a segment.
     v2_lj= eps*((sigma/dd)**12.0d0 - (sigma/dd)**6.0d0 )  - vc
     pot_en2=pot_en2 + v2_lj
  
kcount2=kcount2+1.0d0
  endif !  if(dd.le.sigmac1) then 

enddo  
enddo

write(4,*)jj,pot_en2/npart
endsubroutine lj_energy

subroutine lj_energy_nus
implicit none
integer::i,j,k
real*8::pot_en2,v2_lj,kcount2
real*8:: ddx,ddy,ddz,dd

pot_en2=0.0d0;v2_lj=0.0d0
do i= 1,npart_nus-1
do j=i+1,npart_nus

    ddx=pos_nus(3*i-2) - pos_nus(3*j-2);! if(abs(ddx).gt.llxby2)
    ddy=pos_nus(3*i-1) - pos_nus(3*j-1);! if(abs(ddy).gt.llxby2)
    ddz=pos_nus(3*i) - pos_nus(3*j);! if(abs(ddz).gt.llxby2)

    dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)
    if(dd.le.rc_nus) then ! local attraction between beads in a segment.
     v2_lj= eps*((sigma_nus/dd)**12.0d0 - (sigma_nus/dd)**6.0d0 )  - vc_nus
     pot_en2=pot_en2 + v2_lj

!kcount2=kcount2+1.0d0
  endif !  if(dd.le.sigmac1) then 

enddo
enddo

write(5,*)jj,pot_en2/npart
endsubroutine lj_energy_nus




subroutine binding_partner_rnap
implicit none
integer::i,j,k
real*8::temp_x,temp_y,temp_z
real*8::ddx,ddy,ddz,dd,k_partner

if(jj.gt.niter_rnap_threshold)then
do i=1,no_rrn_operon
if (i.eq.1)then
temp_x=pos(3*rrn_operon1-2)
temp_y=pos(3*rrn_operon1-1)
temp_z=pos(3*rrn_operon1)
endif
if (i.eq.2)then
temp_x=pos(3*rrn_operon2-2)
temp_y=pos(3*rrn_operon2-1)
temp_z=pos(3*rrn_operon2)
endif
if (i.eq.3)then
temp_x=pos(3*rrn_operon3-2)
temp_y=pos(3*rrn_operon3-1)
temp_z=pos(3*rrn_operon3)
endif
if (i.eq.4)then
temp_x=pos(3*rrn_operon4-2)
temp_y=pos(3*rrn_operon4-1)
temp_z=pos(3*rrn_operon4)
endif
if (i.eq.5)then
temp_x=pos(3*rrn_operon5-2)
temp_y=pos(3*rrn_operon5-1)
temp_z=pos(3*rrn_operon5)
endif
if (i.eq.6)then
temp_x=pos(3*rrn_operon6-2)
temp_y=pos(3*rrn_operon6-1)
temp_z=pos(3*rrn_operon6)
endif
if (i.eq.7)then
temp_x=pos(3*rrn_operon7-2)
temp_y=pos(3*rrn_operon7-1)
temp_z=pos(3*rrn_operon7)
endif
do j=1,npart_rnap
ddx= -pos_rnap(3*j-2) + temp_x
ddy= -pos_rnap(3*j-1) + temp_y
ddz= -pos_rnap(3*j) + temp_z
dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)

if(dd.lt.dist_threshold_bind_rnap_poly)then
if(no_partner_rnap_poly(i).lt.no_rnap_per_operon)then
if(partner_rnap_bind_poly(i,j).eq.0.0d0)then
if(bond_index_rnap(j).eq.0.0d0)then
no_partner_poly_rnap(j)=no_partner_poly_rnap(j) +1.0d0
no_partner_rnap_poly(i)=no_partner_rnap_poly(i) + 1.0d0
partner_rnap_bind_poly(i,j)=1.0d0
bond_index_rnap(j)=1.0d0
!write(*,*)'rnap',jj,i,j,no_partner_rnap_poly(i),no_rnap_per_operon
endif
endif
endif
endif

enddo
enddo
endif



!write(*,*)'hi'

do j=1,npart_rnap
k_partner=0.0d0
do i=1,7
if(partner_rnap_bind_poly(i,j).eq.1.0d0)then
k_partner=k_partner+1.0d0

!if(j.eq.527)then
!write(*,*)jj,'culprit',i
!endif

endif

enddo

!if(k_partner.gt.1.0d0)then
!write(*,*)'cheat',j
!endif

enddo







end subroutine binding_partner_rnap

subroutine binding_partner_nus
implicit none
real*8::ddx,ddy,ddz,dd
integer::ij,pp

if(jj.gt.niter_nus_threshold)then
do ij=1, npart_rnap
 do pp= 1,npart_nus

 ddx=pos_rnap(3*ij-2) - pos_nus(3*pp-2); !if(abs(ddx).gt.llxby2)
!ddx=-abs(llx-ddx)*ddx/abs(ddx)

 ddy=pos_rnap(3*ij-1) - pos_nus(3*pp-1); !if(abs(ddy).gt.llxby2)
!ddy=-abs(llx-ddy)*ddy/abs(ddy)

 ddz=pos_rnap(3*ij)   - pos_nus(3*pp)  ; !if(abs(ddz).gt.llxby2)
!ddz=-abs(llx-ddz)*ddz/abs(ddz)


 dd=dsqrt(ddx*ddx + ddy*ddy + ddz*ddz)

if(dd.le.dist_threshold_bind_nus_rnap)then

if(no_partner_nus_rnap(ij).lt.no_nus_per_rnap)then
if(partner_nus_bind_rnap(pp,ij).eq.0.0d0)then
if(bond_index_nus(pp).eq.0.0d0)then
if(bond_index_rnap(ij).eq.1.0d0)then

partner_nus_bind_rnap(pp,ij)=1.0d0
bond_index_nus(pp)=1.0d0
no_partner_nus_rnap(ij)=no_partner_nus_rnap(ij) + 1.0d0

!write(*,*)'nus',jj,pp,ij,partner_nus_bind_rnap(pp,ij),bond_index_nus(pp),no_partner_nus_rnap(ij)

endif
endif
endif
endif
endif

enddo
enddo






endif

end subroutine binding_partner_nus



 subroutine bond_analysis
implicit none
real*8:: ddx,ddy,ddz,dd,av_dist,k_count
integer::n_int,ij,pp,i,j

!!!!!!!!! CHANGE !!!!!!!!!!!!!!!!!
!n_int= abs(rrn_operon1-rrn_operon7)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

ddx=pos(3*rrn_operon1-2) - pos(3*rrn_operon7-2);
!!if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
  ddy=pos(3*rrn_operon1-1) - pos(3*rrn_operon7-1);
!  !if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
  ddz=pos(3*rrn_operon1) - pos(3*rrn_operon7);

  dd=dsqrt(ddx*ddx+ ddy*ddy + ddz*ddz)

write(23,*)jj,dd




ddx=pos(3*rrn_operon3-2) - pos(3*rrn_operon5-2);
!!if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
  ddy=pos(3*rrn_operon3-1) - pos(3*rrn_operon5-1);
!  !if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
  ddz=pos(3*rrn_operon3) - pos(3*rrn_operon5);

  dd=dsqrt(ddx*ddx+ ddy*ddy + ddz*ddz)

write(24,*)jj,dd


ddx=pos(3*rrn_operon4-2) - pos(3*rrn_operon7-2);
!!if(abs(ddx).gt.llxby2) ddx=-abs(llx-ddx)*ddx/abs(ddx)
  ddy=pos(3*rrn_operon4-1) - pos(3*rrn_operon7-1);
!  !if(abs(ddy).gt.llxby2) ddy=-abs(llx-ddy)*ddy/abs(ddy)
  ddz=pos(3*rrn_operon4) - pos(3*rrn_operon7);

  dd=dsqrt(ddx*ddx+ ddy*ddy + ddz*ddz)

write(25,*)jj,dd



av_dist=0.0d0
k_count=0.0d0

!do ij=1, npart-n_int
 ! pp= ij+n_int  

!!!!!!! CHANGE !!!!!!!!!!!!!!!!!
!  if(ij.ne.rrn_operon1)then
!if(ij.ne.rrn_operon7)then
!!!!!!!!!!!!!!!!!!!!!!!!!!!!


 ! ddx=pos_poly(3*ij-2) - pos_poly(3*pp-2); !if(abs(ddx).gt.llxby2)
 ! ddx=-abs(llx-ddx)*ddx/abs(ddx)
 ! ddy=pos_poly(3*ij-1) - pos_poly(3*pp-1); !if(abs(ddy).gt.llxby2)
 ! ddy=-abs(llx-ddy)*ddy/abs(ddy)
 ! ddz=pos_poly(3*ij) - pos_poly(3*pp); !if(abs(ddz).gt.llxby2)
 ! ddz=-abs(llx-ddz)*ddz/abs(ddz)

! dd=dsqrt(ddx*ddx+ ddy*ddy + ddz*ddz)
!write(13,*)dd,dd
!k_count=k_count+1.0d0 

!av_dist=av_dist + dd

!write(*,*)ij,pp,dd
!endif
!endif

 ! enddo
!  enddo

!av_dist=av_dist/k_count


do i=1,npart_rnap-1
do j=i+1,npart_rnap


ddx=pos_rnap(3*i-2) - pos_rnap(3*j-2); !if(abs(ddx).gt.llxby2)
  ddy=pos_rnap(3*i-1) - pos_rnap(3*j-1); !if(abs(ddy).gt.llxby2)
  ddz=pos_rnap(3*i) - pos_rnap(3*j); !if(abs(ddz).gt.llxby2)

dd=dsqrt(ddx*ddx +ddy*ddy + ddz*ddz)


av_dist=av_dist +dd
k_count=k_count+1.0d0

enddo
enddo

av_dist=av_dist/k_count

!write(13,*)jj,av_dist



av_dist=0.0d0
k_count=0.0d0

do i=1,npart_nus-1
do j=i+1,npart_nus


ddx=pos_nus(3*i-2) - pos_nus(3*j-2); !if(abs(ddx).gt.llxby2)
  ddy=pos_nus(3*i-1) - pos_nus(3*j-1); !if(abs(ddy).gt.llxby2)
  ddz=pos_nus(3*i) - pos_nus(3*j); !if(abs(ddz).gt.llxby2)

dd=dsqrt(ddx*ddx +ddy*ddy + ddz*ddz)


av_dist=av_dist +dd
k_count=k_count+1.0d0

enddo
enddo

av_dist=av_dist/k_count

write(14,*)jj,av_dist








end subroutine bond_analysis





end program MC_RING_POLYMER
