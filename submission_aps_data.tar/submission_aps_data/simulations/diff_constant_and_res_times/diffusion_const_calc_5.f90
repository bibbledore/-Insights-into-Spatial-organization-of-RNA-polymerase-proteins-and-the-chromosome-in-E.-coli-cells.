program dist_nus_histogram
    implicit none

    ! --- Parameters ---
    integer, parameter :: npart = 400
    real*8, parameter :: thresh = 10.0d0
    real*8, parameter :: range_x = 50000.0d0
    integer, parameter :: max_no_frames = ((7000000-100)/100)-1
    integer, parameter :: nbins = 100

    ! --- Variables ---
    character(len=30) :: charac_z
    real*8, allocatable :: tempx(:), tempy(:)
    integer :: i9, i5, j, b
    integer :: ios
    real*8 :: dx, slope
!    integer :: histogram(nbins)
    real*8 :: bin_min, bin_max, bin_width
    real*8 :: slope_min, slope_max
    logical :: first_slope
integer(kind=8) :: histogram(nbins)
integer(kind=8) :: total_counts

    ! --- Allocate arrays ---
    allocate(tempx(max_no_frames), tempy(max_no_frames))

    ! --- Initialize histogram ---
    histogram = 0
    first_slope = .true.

    ! --- Loop over particles ---
    do i9 = 1, npart
        ! Build filename
        write(charac_z,'(A,I0)') 'D', i9

        ! Open file safely
        open(84, file='diff_files/'//trim(charac_z), status='old', form='formatted', iostat=ios)
        if (ios /= 0) then
            print *, 'ERROR: Cannot open file for particle ', i9
            cycle
        end if

        ! Read data safely
        tempx = 0.0d0
        tempy = 0.0d0
        do i5 = 1, max_no_frames
            read(84,*,iostat=ios) tempx(i5), tempy(i5)
            if (ios /= 0) exit
        end do
        close(84)

        ! --- Determine global slope min/max dynamically ---
        do i5 = 1, max_no_frames-1
            do j = i5+1, max_no_frames
                dx = tempx(j) - tempx(i5)
                if (dx == 0.0d0) cycle  ! skip division by zero
                slope = (tempy(j) - tempy(i5)) / dx

                if ((j-i5) > 3000 .and. tempy(i5)<thresh .and. tempy(j)<thresh &
                    .and. tempx(i5)>10000 .and. tempx(j)>10000 &
                    .and. tempx(i5)<range_x .and. tempx(j)<range_x &
                    .and. slope>0.0d0) then

                    if (first_slope) then
                        slope_min = slope
                        slope_max = slope
                        first_slope = .false.
                    else
                        if (slope < slope_min) slope_min = slope
                        if (slope > slope_max) slope_max = slope
                    end if
                end if
            end do
        end do
    end do

    ! --- Handle edge case ---
    if (slope_max == slope_min) slope_max = slope_min + 1.0d0
    bin_width = (slope_max - slope_min) / nbins
    histogram = 0

    ! --- Second pass: fill histogram on-the-fly ---
    do i9 = 1, npart
        write(charac_z,'(A,I0)') 'D', i9
        open(84, file='diff_files/'//trim(charac_z), status='old', form='formatted', iostat=ios)
        if (ios /= 0) cycle
        tempx = 0.0d0
        tempy = 0.0d0
        do i5 = 1, max_no_frames
            read(84,*,iostat=ios) tempx(i5), tempy(i5)
            if (ios /= 0) exit
        end do
        close(84)

        do i5 = 1, max_no_frames-1
            do j = i5+1, max_no_frames
                dx = tempx(j) - tempx(i5)
                if (dx == 0.0d0) cycle
                slope = (tempy(j) - tempy(i5)) / dx

                if ((j-i5) > 3000 .and. tempy(i5)<thresh .and. tempy(j)<thresh &
                    .and. tempx(i5)>10000 .and. tempx(j)>10000 &
                    .and. tempx(i5)<range_x .and. tempx(j)<range_x &
                    .and. slope>0.0d0) then

                    ! Compute bin and increment histogram
                    b = int((slope - slope_min) / bin_width) + 1
                    if (b < 1) b = 1
                    if (b > nbins) b = nbins
                    histogram(b) = histogram(b) + 1
                end if
            end do
        end do
        print *, 'Particle ', i9, ' processed for histogram'
    end do
total_counts=sum(histogram)
    ! --- Write histogram to file ---
    open(90, file='slope_histogram.dat', status='replace')
    do b = 1, nbins
!        write(90,*) slope_min + (b-0.5d0)*bin_width, histogram(b)
write(90,*) slope_min + (b-0.5d0)*bin_width, real(histogram(b),8)/real(total_counts,8)


!        write(*,*)sum(histogram)
    end do
    close(90)

    print *, 'Histogram complete!'

end program dist_nus_histogram

