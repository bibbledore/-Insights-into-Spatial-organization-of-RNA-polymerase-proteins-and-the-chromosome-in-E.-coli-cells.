program dist_nus
    implicit none

    ! --- Parameters ---
    integer, parameter :: npart = 5
    real*8, parameter :: thresh = 10.0d0
    real*8, parameter :: range_x = 50000.0d0
    integer, parameter :: max_no_frames = ((7000000-100)/100)-1
    integer, parameter :: nbins = 100

    ! --- Variables ---
    character(len=30) :: charac_z
    real*8, allocatable :: tempx(:), tempy(:)
    real*8, allocatable :: slope_array(:)
    integer :: slope_count_actual
    integer :: i9, i5, j, b
    integer :: ios
    real*8 :: dx, slope
    real*8 :: bin_min, bin_max, bin_width
    integer :: histogram(nbins)
    integer, parameter :: initial_slope_alloc = 1000000  ! initial size

    ! --- Allocate arrays ---
    allocate(tempx(max_no_frames), tempy(max_no_frames))
    allocate(slope_array(initial_slope_alloc))
    slope_count_actual = 0

    ! --- Initialize histogram ---
    histogram = 0

    ! --- Loop over particles ---
    do i9 = 1, npart
        ! Build filename
        write(charac_z,'(A,I0)') 'D', i9

        ! Open file safely
        open(84, file='diff_files/'//trim(charac_z), status='old', form='formatted', iostat=ios)
        if (ios /= 0) then
            print *, 'ERROR: Cannot open file for particle ', i9
            cycle
        end if

        ! Read data safely
        tempx = 0.0d0
        tempy = 0.0d0
        do i5 = 1, max_no_frames
            read(84,*,iostat=ios) tempx(i5), tempy(i5)
            if (ios /= 0) exit
        end do
        close(84)

        ! --- Compute slopes ---
        do i5 = 1, max_no_frames-1
            do j = i5+1, max_no_frames
                dx = tempx(j) - tempx(i5)
                if (dx == 0.0d0) cycle  ! avoid division by zero

                slope = (tempy(j)-tempy(i5)) / dx

                ! Check all conditions
                if ((j-i5) > 3000 .and. tempy(i5)<thresh .and. tempy(j)<thresh &
                    .and. tempx(i5)>10000 .and. tempx(j)>10000 &
                    .and. tempx(i5)<range_x .and. tempx(j)<range_x &
                    .and. slope>0.0d0) then

                    ! --- Store slope safely, realloc if needed ---
                    if (slope_count_actual >= size(slope_array)) then
                        call resize_slope_array(slope_array)
                    end if
                    slope_count_actual = slope_count_actual + 1
                    slope_array(slope_count_actual) = slope
                end if
            end do
        end do

        print *, 'Particle ', i9, ' done, slopes so far = ', slope_count_actual

    end do  ! npart

    ! --- Build histogram ---
    if (slope_count_actual == 0) then
        print *, 'No slopes collected!'
        stop
    end if

    ! Compute min/max
    bin_min = minval(slope_array(1:slope_count_actual))
    bin_max = maxval(slope_array(1:slope_count_actual))
    if (bin_max == bin_min) bin_max = bin_min + 1.0d0
    bin_width = (bin_max - bin_min) / nbins
    histogram = 0

    ! Fill histogram
    do i5 = 1, slope_count_actual
        b = int((slope_array(i5)-bin_min)/bin_width) + 1
        if (b < 1) b = 1
        if (b > nbins) b = nbins
        histogram(b) = histogram(b) + 1
    end do

    ! Write histogram to file
    open(90, file='slope_histogram.dat', status='replace')
    do b = 1, nbins
        write(90,*) bin_min + (b-0.5d0)*bin_width, histogram(b)
    end do
    close(90)

    print *, 'Histogram written. Total slopes = ', slope_count_actual

contains

    subroutine resize_slope_array(arr)
        real*8, allocatable, intent(inout) :: arr(:)
        real*8, allocatable :: tmp(:)
        integer :: old_size, new_size

        old_size = size(arr)
        new_size = 2 * old_size
        allocate(tmp(new_size))
        tmp(1:old_size) = arr
        arr = tmp
    end subroutine resize_slope_array

end program dist_nus

