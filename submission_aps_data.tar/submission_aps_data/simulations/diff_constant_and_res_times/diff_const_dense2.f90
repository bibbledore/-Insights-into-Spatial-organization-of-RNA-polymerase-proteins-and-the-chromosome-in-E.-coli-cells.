program slope_hist_probability
implicit none

integer, parameter :: npart = 400
integer :: i, nbins, b
real*8 :: slope(npart)
real*8 :: slope_min, slope_max, bin_width
real*8, allocatable :: histogram(:)
real*8 :: value
character(len=100) :: filename

! -----------------------------
!  Example: Fill slopes (REPLACE with your values)
! -----------------------------
do i = 1, npart
    slope(i) = 0.5d0 * i + 2.0d0   ! dummy values
end do

! -----------------------------
!  Find min and max automatically
! -----------------------------
slope_min = slope(1)
slope_max = slope(1)
do i = 2, npart
    if (slope(i) < slope_min) slope_min = slope(i)
    if (slope(i) > slope_max) slope_max = slope(i)
end do

! -----------------------------
!  Choose number of bins
! -----------------------------
nbins = 50

allocate(histogram(nbins))
histogram = 0.0d0

! -----------------------------
!  Bin width based on data
! -----------------------------
bin_width = (slope_max - slope_min) / dble(nbins)

! -----------------------------
!  Fill histogram
! -----------------------------
do i = 1, npart
    value = slope(i)
    b = int((value - slope_min) / bin_width) + 1

    if (b < 1) b = 1
    if (b > nbins) b = nbins

    histogram(b) = histogram(b) + 1.0d0
end do

! -----------------------------
!  Convert counts → probability
!  Normalize so total probability = 1
! -----------------------------
do b = 1, nbins
    histogram(b) = histogram(b) / dble(npart)
end do

! -----------------------------
!  Write histogram to file
! -----------------------------
filename = 'slope_hist_probability.dat'
open(unit=31, file=filename, status='replace', action='write')

do b = 1, nbins
    value = slope_min + (b - 0.5d0)*bin_width
    write(31,'(F12.6,1x,F12.6)') value, histogram(b)
end do

close(31)

print *, 'Probability histogram written to: ', filename

end program slope_hist_probability

