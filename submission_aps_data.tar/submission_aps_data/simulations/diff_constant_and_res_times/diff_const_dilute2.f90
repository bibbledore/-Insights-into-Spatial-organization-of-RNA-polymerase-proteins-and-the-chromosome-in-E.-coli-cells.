program dist_nus

implicit none

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer::j11,k
integer,parameter::npart=400
integer,parameter::max_no_frames=(826500-100)/100
character(len=30) :: charac_a,charac_g
character(len=2)::charac_b
integer::cluster_id(npart)
real*8::tempx,tempy,tempz,temp
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart),k_c
real*8::dx,dy,dz,dd,x_com,y_com,z_com,rad_g,dd2
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
integer::frame_count,residence_time
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)
real*8:: entry_time(npart,max_no_frames),exit_time(npart,max_no_frames)
real*8:: cluster_index_frame(npart,max_no_frames)
real*8::first_entry_time(npart),first_exit_time(npart)
real*8:: entry_recorded(npart),instances_of_clustering(npart),frame_where_in_cluster(npart,max_no_frames)
integer::this_frame,prev_frame
integer::k30
real*8::pos_temp_1_x,pos_temp_1_y,pos_temp_1_z
real*8::pos_temp_2_x,pos_temp_2_y,pos_temp_2_z
integer::config,config2,config1
real*8::slope
integer::msd_frame_count

cluster_index_frame=0.0d0
instances_of_clustering=0.0d0
frame_where_in_cluster=0.0d0
bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0
k3=0
frame_count=0

do i=100,826500,100

frame_count=frame_count+1

pos=0.0d0
bond_index=0.0d0
neigh_list=0.0d0
no_neighbors=0.0d0

charac_a ='store_'
call addnumtostring(charac_a,i)

k3=0
open(83,file=charac_a,status='unknown',form='formatted')
do j=1,1867
   read(83,'(A,3g18.10)') charac_b,tempx,tempy,tempz
   if(charac_b.eq.'Na')then
      k3=k3+1
      pos(3*k3-2)=tempx
      pos(3*k3-1)=tempy
      pos(3*k3)=tempz
   endif
enddo
close(83)

! --- Build neighbor list ---
do k1=1,npart-1
  do k2=k1+1,npart
    dx=pos(3*k1-2)-pos(3*k2-2)
    dy=pos(3*k1-1)-pos(3*k2-1)
    dz=pos(3*k1)-pos(3*k2)
    dd=sqrt(dx**2+dy**2+dz**2)
    if(dd.lt.cluster_dist_thresh)then
       neigh_list(k1,k2)=1.0d0
       neigh_list(k2,k1)=1.0d0
       no_neighbors(k1)=no_neighbors(k1)+1
       no_neighbors(k2)=no_neighbors(k2)+1
    endif
  enddo
enddo

! --- Cluster search ---
cluster_index = 0
cluster_index_actual=0
visited = 0
visited_actual = 0
no_part_in_cluster = 0
no_part_in_cluster_actual = 0
cluster_id=0

do k1 = 1, npart
   if (visited(k1) == 0) then
      cluster_index = cluster_index + 1
      no_part_in_cluster(cluster_index) = 1
      visited(k1)=1
      cluster_id(k1)=cluster_index

      added = 1
      do while (added == 1)
         added = 0
         do k2 = 1, npart
            if (visited(k2)==0) then
               do j=1,npart
                  if(visited(j)==1 .and. neigh_list(k2,j)==1.0d0)then
                     visited(k2)=1
                     cluster_id(k2)=cluster_index
                     no_part_in_cluster(cluster_index)=no_part_in_cluster(cluster_index)+1
                     added=1
                     exit
                  endif
               enddo
            endif
         enddo
      enddo

      if(no_part_in_cluster(cluster_index) < 5)then
         cluster_index_actual = cluster_index_actual + 1
         no_part_in_cluster_actual(cluster_index_actual) = no_part_in_cluster(cluster_index)
         do p=1,npart
            if(cluster_id(p)==cluster_index) visited_actual(p)=1
         enddo
      endif

   endif
enddo

visited_actual_max=0
imax=1
do ii=2,cluster_index
   if(no_part_in_cluster(ii) > no_part_in_cluster(imax)) imax=ii
enddo

do k=1,npart
   if(cluster_id(k)==imax)then
      visited_actual_max(k)=1
   else
      visited_actual_max(k)=0
   endif
enddo

do k=1,npart
   if(visited_actual(k)==1)then
      cluster_index_frame(k,frame_count)=1
      instances_of_clustering(k)=instances_of_clustering(k)+1
      frame_where_in_cluster(k,instances_of_clustering(k))=i
   endif
enddo

enddo  ! time loop

! ===== Post-processing =====

do j=1,npart

residence_time=1
msd_frame_count=1

if(instances_of_clustering(j) > 1)then
   do k=3,int(instances_of_clustering(j))
      this_frame=frame_where_in_cluster(j,k)/100
      prev_frame=frame_where_in_cluster(j,k-1)/100

      if(this_frame == prev_frame+1)then
         residence_time=residence_time+1
         msd_frame_count=msd_frame_count+1
      else
         if(msd_frame_count > 1)then

            config1 = (this_frame-(msd_frame_count-1))*100
            config2 = this_frame*100
            config = config1

            ! Read frame 1
            charac_g='store_'
            call addnumtostring(charac_g,config1)

            open(83,file=charac_g,status='unknown',form='formatted')
            k30=0
            do j11=1,1867
               read(83,'(A,3g18.10)') charac_b,tempx,tempy,tempz
               if(charac_b=='Na')then
                  k30=k30+1
                  if(k30==j)then
                     pos_temp_1_x=tempx
                     pos_temp_1_y=tempy
                     pos_temp_1_z=tempz
                  endif
               endif
            enddo
            close(83)

            ! Read frame 2
            charac_g='store_'
            call addnumtostring(charac_g,config2)

            open(83,file=charac_g,status='unknown',form='formatted')
            k30=0
            do j11=1,1867
               read(83,'(A,3g18.10)') charac_b,tempx,tempy,tempz
               if(charac_b=='Na')then
                  k30=k30+1
                  if(k30==j)then
                     pos_temp_2_x=tempx
                     pos_temp_2_y=tempy
                     pos_temp_2_z=tempz
                  endif
               endif
            enddo
            close(83)

            dx=pos_temp_2_x-pos_temp_1_x
            dy=pos_temp_2_y-pos_temp_1_y
            dz=pos_temp_2_z-pos_temp_1_z
            dd = dx*dx+dy*dy+dz*dz
            slope = dd/(config2-config1)
!            if(slope.lt.0.0050d0)then

            write(41,*)slope
 !   endif
         endif

         write(72,*)residence_time,residence_time
         residence_time=1
         msd_frame_count=1
      endif
   enddo

   if(residence_time > 1) write(72,*)residence_time,residence_time

endif

enddo

! ======================
contains
! ======================

subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) :: string

snum=number
do i=len(string),1,-1
   if(string(i:i) /= ' ') goto 10
enddo
10 strlen=i

nodig=int(log10(1.0*snum+0.1))+1

do i=nodig,1,-1
   num=snum/10**(i-1)
   string(strlen+1:strlen+1)=char(48+num)
   strlen=strlen+1
   snum=snum-num*10**(i-1)
enddo

end subroutine addnumtostring

end program dist_nus

