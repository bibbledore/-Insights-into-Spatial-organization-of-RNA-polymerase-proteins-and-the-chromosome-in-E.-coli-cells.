program dist_nus

implicit none

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer,parameter::npart=400
real*8,parameter::thresh=10.0d0
real*8,parameter::range_x=50000.0d0
integer,parameter::max_no_frames=((7000000-100)/100)-1
character(len=30) :: charac_z
character(len=2)::charac_b
integer::cluster_id(npart)
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart),k_c
real*8::dx,dy,dz,dd,x_com,y_com,z_com,rad_g,dd2
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
integer::frame_count,residence_time
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)
real*8:: entry_time(npart,max_no_frames),exit_time(npart,max_no_frames)
real*8:: cluster_index_frame(npart,max_no_frames)
real*8::first_entry_time(npart),first_exit_time(npart)
real*8:: entry_recorded(npart),instances_of_clustering(npart),frame_where_in_cluster(npart,max_no_frames)
real*8:: cluster_label(npart),no_of_clusters
real*8:: pos_store_frames_x(max_no_frames),pos_store_frames_y(max_no_frames)
integer::this_frame,prev_frame,i9,i5
real*8::tempx(max_no_frames),tempy(max_no_frames)
real*8::slope

! ---------- Histogram storage ----------
integer, parameter :: max_slopes = 200000*10
integer::max_slopes_per_run=max_slopes/10
real*8 :: slope_array(max_slopes)
integer :: slope_count
integer ::slope_count_actual
integer ::slope_count_global
!slope_count = 0
integer, parameter :: nbins = 100
real*8 :: bin_min, bin_max, bin_width
integer :: histogram(nbins), b

slope_count=0
slope_count_actual=0
! ----------------------------------------

do i9=1,npart

slope_count=0

tempy=0.0d0;tempx=0.0d0
write(*,*)i9
!write(*,*)'hi'
    charac_z='D'
    call addnumtostring(charac_z,i9)

    open(84,file='diff_files/'//trim(charac_z),status='unknown',form='formatted')

    do i=1,max_no_frames
        read(84,*) tempx(i), tempy(i)
    end do

!    write(*,*)'hi'
    do i5 = 1, max_no_frames-1
        do j = i5+1, max_no_frames

            k1 = j - i5
            slope = (tempy(j) - tempy(i5)) / (tempx(j) - tempx(i5))
!write(*,*)'hi'

            if (k1.gt.3000) then
            if (tempy(j).lt.thresh) then
            if (tempy(i5).lt.thresh) then
            if (tempx(i5).gt.10000) then
            if (tempx(j).gt.10000) then
            if (tempx(i5).lt.range_x) then
            if (tempx(j).lt.range_x) then
            if (slope .gt. 0.0d0) then

                slope_count = slope_count + 1
                if (slope_count <= max_slopes_per_run)then 
           !     slope_array(slope_count) = slope
slope_count_actual=slope_count_actual+1
slope_array(slope_count_actual) = slope
!write(*,*)slope_count,slope_count_actual
!write
            endif
            endif
            endif
            endif
            endif
            endif
            endif
    endif
    endif
        end do
    end do

    close(84)

end do
!write(*,*)'hi'
! =============================================================
!           BUILD HISTOGRAM WITH AUTO MIN/MAX
! =============================================================

!integer, parameter :: nbins = 100
!real*8 :: bin_min, bin_max, bin_width
!integer :: histogram(nbins), b

! ---- Compute min and max ----
bin_min = 1.0d300
bin_max = -1.0d300

do i = 1, slope_count_actual
write(*,*)i,slope_array(i)
if (slope_array(i) < bin_min) bin_min = slope_array(i)
    if (slope_array(i) > bin_max) bin_max = slope_array(i)
end do
write(*,*)'hi'

! Handle corner case (all slopes equal)
if (bin_max == bin_min) then
    bin_max = bin_min + 1.0d0
endif

histogram = 0
bin_width = (bin_max - bin_min) / nbins

! Fill histogram
do i = 1, slope_count_actual
    b = int((slope_array(i) - bin_min) / bin_width) + 1
    if (b < 1) b = 1
    if (b > nbins) b = nbins
    histogram(b) = histogram(b) + 1
end do

! Write histogram to file
open(90,file="slope_histogram.dat",status="replace")
do b = 1, nbins
    write(90,*) bin_min + (b-0.5d0)*bin_width, histogram(b)
end do
close(90)

contains

subroutine addnumtostring(string,number)
    implicit none
    integer :: i,strlen,number,nodig,num,snum
    character*(*) ::  string

    snum = number
    do i = len(string),1,-1
        if (string(i:i) .ne. ' ') goto 10
    end do
10  strlen = i

    nodig = int(log10(1.0*snum+0.1))+1
    do i = nodig,1,-1
        num = snum / 10**(i-1)
        string(strlen+1:strlen+1)=char(48+num)
        strlen = strlen + 1
        snum = snum - num*10**(i-1)
    end do

end subroutine addnumtostring

end program dist_nus

