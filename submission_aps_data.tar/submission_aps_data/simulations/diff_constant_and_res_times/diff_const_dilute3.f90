program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer::j11
integer,parameter::npart=400
integer,parameter::max_no_frames=(826500-100)/100
character(len=30) :: charac_a
character(len=2)::charac_b
integer::cluster_id(npart)
real*8::tempx,tempy,tempz,temp
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart),k_c
real*8::dx,dy,dz,dd,x_com,y_com,z_com,rad_g,dd2
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
integer::frame_count,residence_time
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)
real*8:: entry_time(npart,max_no_frames),exit_time(npart,max_no_frames)
real*8:: cluster_index_frame(npart,max_no_frames)
real*8::first_entry_time(npart),first_exit_time(npart)
real*8:: entry_recorded(npart),instances_of_clustering(npart),frame_where_in_cluster(npart,max_no_frames)
integer::this_frame,prev_frame

! ------------------- BEGIN NEW DECLARATIONS -------------------
integer :: nbins, bin_index
real*8 :: slope_min, slope_max, bin_width, slope_center
real*8, allocatable :: slopes(:)
integer, allocatable :: histogram(:)
integer :: slope_count
real*8 :: slope, pos_temp_1_x, pos_temp_1_y, pos_temp_1_z
real*8 :: pos_temp_2_x, pos_temp_2_y, pos_temp_2_z
integer :: config, config2, k30, msd_frame_count
! ------------------- END NEW DECLARATIONS ---------------------

cluster_index_frame=0.0d0
instances_of_clustering=0.0d0
frame_where_in_cluster=0.0d0
bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0
k3=0
frame_count=0

! ------------------- BEGIN NEW -------------------
allocate(slopes(10000000))
slope_count = 0
! ------------------- END NEW ---------------------

do i=100,826500,100

frame_count=frame_count+1

pos=0.0d0
bond_index=0.0d0
neigh_list=0.0d0
no_neighbors=0.0d0

charac_a ='store_'
call addnumtostring(charac_a,i)
k3=0

open(83,file=charac_a,status='unknown',form='formatted')
do j=1,1867
    read(83,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
    if(charac_b.eq.'Na')then
        k3=k3+1
        pos(3*k3-2)=tempx
        pos(3*k3-1)=tempy
        pos(3*k3)=tempz
    endif
enddo
close(83)

do k1=1,npart-1
   do k2=k1+1,npart
      dx=pos(3*k1-2)-pos(3*k2-2)
      dy=pos(3*k1-1)-pos(3*k2-1)
      dz=pos(3*k1)-pos(3*k2)
      dd=dsqrt(dx**2.0d0 + dy**2.0d0 + dz**2.0d0)
      if(dd.lt.cluster_dist_thresh)then
         neigh_list(k1,k2)=1.0d0
         neigh_list(k2,k1)=1.0d0
         no_neighbors(k1)=no_neighbors(k1) +1.0d0
         no_neighbors(k2)=no_neighbors(k2) +1.0d0
      endif
   enddo
enddo

cluster_index = 0
cluster_index_actual=0
visited = 0
visited_actual=0
no_part_in_cluster = 0
no_part_in_cluster_actual = 0
cluster_id=0

do k1 = 1, npart
   if (visited(k1) == 0) then
      cluster_index = cluster_index + 1
      visited(k1) = 1
      no_part_in_cluster(cluster_index) = 1.0d0
      cluster_id(k1) = cluster_index

      added = 1
      do while (added == 1)
         added = 0
         do k2 = 1, npart
            if (visited(k2) == 0) then
               do j = 1, npart
                  if (visited(j) == 1 .and. neigh_list(k2,j) == 1.0d0) then
                     visited(k2) = 1
                     no_part_in_cluster(cluster_index)=no_part_in_cluster(cluster_index) + 1.0d0
                     cluster_id(k2) = cluster_index
                     added = 1
                     exit
                  endif
               end do
            endif
         end do
      end do

      if (no_part_in_cluster(cluster_index) < 5.0d0) then
         cluster_index_actual = cluster_index_actual + 1
         no_part_in_cluster_actual(cluster_index_actual) = no_part_in_cluster(cluster_index)
         do p = 1, npart
            if (visited(p) == 1) visited_actual(p) = 1
         end do
      end if
   end if
end do

imax = 1
do ii = 2, cluster_index
   if (no_part_in_cluster(ii) > no_part_in_cluster(imax)) then
      imax = ii
   end if
end do

do k = 1, npart
   if (cluster_id(k) == imax) then
      visited_actual_max(k) = 1
   else
      visited_actual_max(k) = 0
   end if
end do

do k=1,npart
   if(visited_actual(k).eq.1)then
      cluster_index_frame(k,frame_count)=1.0d0
      instances_of_clustering(k)=instances_of_clustering(k)+ 1.0d0
      frame_where_in_cluster(k,instances_of_clustering(k))=i
   endif
enddo

enddo  ! END time loop


!======================================================================
!          RESIDENCE TIMES + MSD + SLOPE COLLECTION
!======================================================================

do j=1,npart

residence_time=1
msd_frame_count=1

if (instances_of_clustering(j).gt.1.0d0)then
do k=3,int(instances_of_clustering(j))

this_frame=frame_where_in_cluster(j,k)/100
prev_frame=frame_where_in_cluster(j,k-1)/100

if(this_frame.eq.(prev_frame+1))then
   residence_time=residence_time+1
   msd_frame_count=msd_frame_count+1

else

   if (msd_frame_count.gt.1)then

      config=(this_frame-(msd_frame_count-1))*100
      config2=(this_frame)*100

      charac_g ='store_'
      call addnumtostring(charac_g,config)

      k30=0
      open(83,file=charac_g,status='unknown',form='formatted')
      do j11=1,1867
         read(83,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
         if(charac_b.eq.'Na')then
            k30=k30+1
            if(k30.eq.j)then
               pos_temp_1_x=tempx
               pos_temp_1_y=tempy
               pos_temp_1_z=tempz
            endif
         endif
      enddo
      close(83)

      charac_g ='store_'
      call addnumtostring(charac_g,config2)

      k30=0
      open(83,file=charac_g,status='unknown',form='formatted')
      do j11=1,1867
         read(83,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
         if(charac_b.eq.'Na')then
            k30=k30+1
            if(k30.eq.j)then
               pos_temp_2_x=tempx
               pos_temp_2_y=tempy
               pos_temp_2_z=tempz
            endif
         endif
      enddo
      close(83)

      dx = pos_temp_2_x - pos_temp_1_x
      dy = pos_temp_2_y - pos_temp_1_y
      dz = pos_temp_2_z - pos_temp_1_z

      dd = dx*dx + dy*dy + dz*dz

      slope = dd / (config2-config)

      write(41,*) slope, slope

      ! ----------- BEGIN NEW: store slopes -------------
      slope_count = slope_count + 1
      slopes(slope_count) = slope
      ! ----------- END NEW -----------------------------

   endif

   residence_time=1
endif

enddo

endif
enddo



!======================================================================
!                     HISTOGRAM OF SLOPES
!======================================================================

if (slope_count > 1) then

    slope_min = slopes(1)
    slope_max = slopes(1)
    do i = 2, slope_count
        if (slopes(i) < slope_min) slope_min = slopes(i)
        if (slopes(i) > slope_max) slope_max = slopes(i)
    end do

    nbins = 100
    bin_width = (slope_max - slope_min) / nbins

    allocate(histogram(nbins))
    histogram = 0

    do i = 1, slope_count
        bin_index = int((slopes(i) - slope_min)/bin_width) + 1
        if (bin_index < 1) bin_index = 1
        if (bin_index > nbins) bin_index = nbins
        histogram(bin_index) = histogram(bin_index) + 1
    end do

    open(99,file='slope_histogram.dat',status='replace')
    do i = 1, nbins
        slope_center = slope_min + (i-0.5d0)*bin_width
        write(99,*) slope_center, histogram(i)
    end do
    close(99)

endif


contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i

      nodig=int(log10(1.0*snum+0.1))+1
      do i=nodig,1,-1
         num=snum/10**(i-1)
         string(strlen+1:strlen+1)=char(48+num)
         strlen=strlen+1
         snum=snum-num*10**(i-1)
      enddo
end subroutine addnumtostring

endprogram dist_nus

