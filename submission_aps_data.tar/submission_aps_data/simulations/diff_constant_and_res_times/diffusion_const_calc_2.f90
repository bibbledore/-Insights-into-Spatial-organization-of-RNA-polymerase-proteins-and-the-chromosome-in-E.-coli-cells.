program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer,parameter::npart=400
real*8,parameter::thresh=10.0d0
real*8,parameter::range_x=50000.0d0
integer,parameter::max_no_frames=((7000000-100)/100)-1
character(len=30) :: charac_a,charac_z
character(len=2)::charac_b
integer::cluster_id(npart)
!real*8::tempx,tempy,tempz,temp
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart),k_c
real*8::dx,dy,dz,dd,x_com,y_com,z_com,rad_g,dd2
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
integer::frame_count,residence_time
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)
real*8:: entry_time(npart,max_no_frames),exit_time(npart,max_no_frames)
real*8:: cluster_index_frame(npart,max_no_frames)
real*8::first_entry_time(npart),first_exit_time(npart)
real*8:: entry_recorded(npart),instances_of_clustering(npart),frame_where_in_cluster(npart,max_no_frames)
real*8:: cluster_label(npart),no_of_clusters
real*8:: pos_store_frames_x(max_no_frames),pos_store_frames_y(max_no_frames),pos_store_frames_z(max_no_frames)
integer::this_frame,prev_frame,i9,i5
real*8::dist_frames(max_no_frames),count_frames(max_no_frames)
real*8::tempx(max_no_frames),tempy(max_no_frames),slope

do k9=1,1

charac_z='D'
call addnumtostring(charac_z,k9)
!write(*,*)charac_z
open(084,file='diff_files/'//trim(charac_z),status='unknown',form='formatted')

do i=1,max_no_frames
!write(*,*)i,max_no_frames
read(84,*)tempx(i),tempy(i)

enddo

!write(*,*)'hi'

do i5=1,max_no_frames-1
do j=i5+1,max_no_frames

k4=j-i5


slope=(tempy(j)-tempy(i5))/(tempx(j)-tempx(i5))
if(k4.gt.3000)then
if(tempy(j).lt.thresh)then

        if(tempy(i5).lt.thresh)then
if(tempx(i5).gt.10000)then
if(tempx(j).gt.10000)then


                if(tempx(i5).lt.range_x)then
if(tempx(j).lt.range_x)then

    if(slope.gt.0.0d0)then                    
                        write(82,*)slope,slope
!write(*,*)i5,j,k4,slope
                endif

        endif
endif
endif
endif
endif
endif
endif
enddo
enddo


close(84)

enddo

contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
