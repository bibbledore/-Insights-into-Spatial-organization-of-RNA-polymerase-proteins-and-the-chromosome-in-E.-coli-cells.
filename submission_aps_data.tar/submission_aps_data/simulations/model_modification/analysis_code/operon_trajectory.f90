program dist_nus

integer::i,ij,j,k1,k2,k3,cluster_index,added,i1,k_count,cluster_index_actual,j1
integer,parameter::npart=7
character(len=30) :: charac_a
character(len=2)::charac_b
integer::cluster_id(npart),k_count2
real*8::tempx,tempy,tempz
real*8,parameter::cluster_dist_thresh=0.50d0
real*8::pos(3*npart)
real*8::dx,dy,dz,dd,x_com,y_com,z_com
real*8::neigh_list(npart,npart),no_neighbors(npart)
real*8::bond_index(npart)
integer::visited(npart),visited_actual(npart),p,imax,visited_actual_max(npart),ii
real*8:: no_part_in_cluster(npart),no_part_in_cluster_actual(npart)

!allocate(visited(npart),no_part_in_cluster(npart))

bond_index=0.0d0
charac_a ='store_'
neigh_list=0.0d0
no_neighbors=0.0d0

!pos=0.0d0
k3=0
do i=10000,8000000,10000

pos=0.0d0
bond_index=0.0d0
neigh_list=0.0d0
no_neighbors=0.0d0



!do i=500000,500000
charac_a ='store_'

       call addnumtostring(charac_a,i)
!write(*,*)charac_a
k3=0

       open(083,file=charac_a,status='unknown',form='formatted')
do j=1,1867
read(083,fmt='(A,3g18.10)') charac_b,tempx,tempy,tempz
!write(*,*)tempx,tempy,tempz
!if(charac_b.eq.'N'.or.charac_b.eq.'Na')then
!if(charac_b.eq.'N'.or.charac_b.eq.'Na')then
!k3=k3+1
!pos(3*k3-2)=tempx
!pos(3*k3-1)=tempy
!pos(3*k3)=tempz
!write(*,*)k3,j

if(charac_b.eq.'Na')then
bond_index(k3)=1.0d0
!write(*,*)i,j,k3,bond_index(k3),charac_b
elseif(charac_b.eq.'N')then
bond_index(k3)=2.0d0
elseif(charac_b.eq.'C')then
bond_index(k3)=3.0d0
elseif(charac_b.eq.'H')then
bond_index(k3)=4.0d0

k3=k3+1
pos(3*k3-2)=tempx
pos(3*k3-1)=tempy
pos(3*k3)=tempz


else
bond_index(k3)=5.0d0
endif


!endif


enddo
close(083)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!! Trajectory!!!!!!!!!!!
!write(72,*)''
write(72,*)'7'
write(72,*)''

do i1=1,npart
!write(*,*)i1,npart
!if(bond_index(i1).eq.4.0d0)then
      !  if(visited_actual_max(i1).ne.1)then
      if(i1.eq.1)then
      write(72,*)'H',pos(3*i1-2),pos(3*i1-1),pos(3*i1)
elseif (i1.eq.2)then     
write(72,*)'He',pos(3*i1-2),pos(3*i1-1),pos(3*i1)
elseif (i1.eq.3)then
write(72,*)'Ne',pos(3*i1-2),pos(3*i1-1),pos(3*i1)
elseif (i1.eq.4)then
write(72,*)'Na',pos(3*i1-2),pos(3*i1-1),pos(3*i1)
elseif (i1.eq.5)then
write(72,*)'Mg',pos(3*i1-2),pos(3*i1-1),pos(3*i1)
elseif (i1.eq.6)then
write(72,*)'F',pos(3*i1-2),pos(3*i1-1),pos(3*i1)
elseif (i1.eq.7)then
!write(*,*)'hi',i1
        write(72,*)'Al',pos(3*i1-2),pos(3*i1-1),pos(3*i1)
 endif

!endif


enddo
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

enddo

contains
subroutine addnumtostring(string,number)
implicit none
integer :: i,strlen,number,nodig,num,snum
character*(*) ::  string

      snum=number
      do i=len(string),1,-1
       if (string(i:i) .ne. ' ') goto 10
      enddo
   10 strlen=i


        nodig=int(log10(1.0*snum+0.1))+1
        do i=nodig,1,-1
       num=snum/10**(i-1)
       string(strlen+1:strlen+1)=char(48+num)
       strlen=strlen+1
       snum=snum-num*10**(i-1)
  enddo

        return
end subroutine addnumtostring





endprogram dist_nus
