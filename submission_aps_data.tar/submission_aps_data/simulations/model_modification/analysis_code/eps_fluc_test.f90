program eps_fluc
implicit none

real*8 :: eps, u1, u2, z
real*8, parameter :: sigma = 0.10d0    ! 5% fluctuation strength
integer :: i, jj

!eps = 10.0d0
call random_seed()

open(11, file="eps_output.dat", status="replace")

do i = 1, 80000000
eps=2.50d0

    ! Generate Gaussian noise z using Box–Muller method
    call random_number(u1)
    call random_number(u2)
    z = sqrt(-2.0d0*log(u1)) * cos(2.0d0*acos(-1.0d0)*u2)

    ! Update eps (multiplicative Gaussian noise)

    if(mod(i,100000).eq.0)then
    eps = eps + (sigma*eps *z)
    endif

    ! Print every 1000 iterations
    if (mod(i, 1000) == 0) then
        write(11,*) i, eps
    end if

end do

close(11)
end program eps_fluc

